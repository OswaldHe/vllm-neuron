# SPDX-License-Identifier: Apache-2.0
"""Building blocks shared by the layer and drafter megakernels.

Plain Python helpers traced inside a `@nki.jit` body: none of them is a kernel
on its own. Every helper is written for the two physical cores of a logical
NeuronCore (LNC=2): a helper either takes the row/column range the calling core
owns, or says in its docstring that it runs on both cores unchanged.

Numerics mirror the shipped per-op kernels (`blockquant`, `hc_in`, `hc_attn_out`,
`sparse_attn`), which were validated token for token against the checkpoint's
reference: the values written to the KV caches round-trip through `_qdq_fp8`
(FP8_PEAK = 224), the quantized GEMMs run on the tensor engine's MX matmul
(`mk_mx`, which quantizes their inputs on chip), fp32 PSUM accumulation, bf16
roundings at the same points as the torch path.
"""

import nki.collectives as ncc
import nki.isa as nisa
import nki.language as nl

from .. import moe_tp

from . import mk_mx as X
from .blockquant import (  # noqa: F401 - re-exported for the megakernels
    BLK,
    PT,
    _gemm,
    _qdq_fp8,
    _stage_rows,
)

#: `rms_norm_eps`, `hc_sinkhorn_iters`, `hc_eps` -- the config's.
NORM_EPS = 1e-20
SINKHORN_ITERS = 20
HC_EPS = 1e-06
#: RoPE: adjacent element pairs over the last `ROPE_DIM` columns of a head.
ROPE_DIM = 64
ROPE_HALF = ROPE_DIM // 2
#: `sparse_attn`'s empty-slot bias and the slot-tile width it gathers in.
NEG_BOUND = -1.0e30
KTILE = 128
#: A psum bank: 512 fp32 per partition.
PSUM_FP32 = 512


def cdiv(n, d):
    return (n + d - 1) // d


def pad_to(n, m):
    return cdiv(n, m) * m


def tiles_of(rows, pid, cores=2):
    """`(r0, nr)` for the 128-row tiles of `rows` that core `pid` owns (tile `i`
    to core `i % cores`). The partial last tile goes to its owner like any other.
    """
    out = []
    for i in range(cdiv(rows, PT)):
        if i % cores == pid:
            r0 = i * PT
            out.append((r0, min(PT, rows - r0)))
    return out


def rsqrt_newton(m):
    """`1 / sqrt(m)` (round 5: the hardware rsqrt is within 1 fp32 ulp -- no Newton step, which
    `kernels.rmsnorm` did)."""
    return nl.rsqrt(m)


def sum_squares(dst, src, nr, width, chunk):
    """`dst[0:nr] = sum(src[0:nr, 0:width]^2)` in fp32 on the scalar engine."""
    junk = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
    nchunks = width // chunk
    for c in range(nchunks):
        last = c == nchunks - 1
        nisa.activation(
            dst=junk[0:nr, 0:chunk],
            op=nl.square,
            data=src[0:nr, c * chunk : (c + 1) * chunk],
            reduce_op=nl.add,
            reduce_cmd=nisa.reduce_cmd.reset_reduce if c == 0 else nisa.reduce_cmd.reduce,
            reduce_res=dst[0:nr, 0:1] if last else None,
        )


def bcast_row(hbm_row, n, nr, dtype=nl.float32):
    """`hbm_row[0:1, 0:n]` broadcast to `nr` partitions as an SBUF tile."""
    return nl.broadcast_to(nl.load(hbm_row[0:1, 0:n], dtype=dtype), (nr, n))


#: Row-invariant operands broadcast to the partitions by one DMA with a zero partition
#: stride (`bcast_dma`) instead of a load plus an on-chip partition broadcast (DVE /
#: GpSimd work on the serial row-tile chains).
BCAST_DMA = True


def bcast_dma(t_hbm, col0, n, nr, dtype=nl.float32):
    """`t_hbm[0, col0 : col0 + n]` on `nr` partitions as an SBUF tile of `dtype` (the
    same values as `bcast_row`: a bf16 row widened exactly by a copy)."""
    if not BCAST_DMA:
        t = nl.ndarray((nr, n), dtype=dtype, buffer=nl.sbuf)
        nisa.tensor_copy(dst=t, src=bcast_row(t_hbm[0:1, col0 : col0 + n], n, nr, dtype=dtype))
        return t
    raw = nl.ndarray((nr, n), dtype=t_hbm.dtype, buffer=nl.sbuf)
    nisa.dma_copy(dst=raw, src=t_hbm.ap(pattern=[[0, nr], [1, n]], offset=col0))
    if t_hbm.dtype == dtype:
        return raw
    t = nl.ndarray((nr, n), dtype=dtype, buffer=nl.sbuf)
    nisa.tensor_copy(dst=t, src=raw)
    return t


# --------------------------------------------------------------------------- hyper-connections


def sinkhorn(t2, nr, hc):
    """`softmax(rows) + eps`, then the 20 alternating normalizations of `kernels.hc_in`."""

    def rowsum_div(src, dst):
        for i in range(hc):
            lo, hi = i * hc, (i + 1) * hc
            s = nl.sum(src[0:nr, lo:hi], axis=1, keepdims=True)
            nisa.tensor_scalar(
                dst=dst[0:nr, lo:hi], data=src[0:nr, lo:hi],
                op0=nl.multiply, operand0=nl.reciprocal(nl.add(s, HC_EPS)),
            )

    def colsum_div(src, dst):
        s = nl.add(src[0:nr, 0:hc], src[0:nr, hc : 2 * hc])
        for i in range(2, hc):
            s = nl.add(s, src[0:nr, i * hc : (i + 1) * hc])
        d = nl.reciprocal(nl.add(s, HC_EPS))
        for i in range(hc):
            lo, hi = i * hc, (i + 1) * hc
            nisa.tensor_tensor(
                dst=dst[0:nr, lo:hi], data1=src[0:nr, lo:hi], data2=d, op=nl.multiply
            )

    a = nl.ndarray((PT, hc * hc), dtype=nl.float32, buffer=nl.sbuf)
    b = nl.ndarray((PT, hc * hc), dtype=nl.float32, buffer=nl.sbuf)
    for i in range(hc):
        lo, hi = i * hc, (i + 1) * hc
        mx = nl.max(t2[0:nr, lo:hi], axis=1, keepdims=True)
        e = nl.exp(nl.subtract(t2[0:nr, lo:hi], nl.broadcast_to(mx, (nr, hc))))
        s = nl.sum(e, axis=1, keepdims=True)
        nisa.tensor_scalar(
            dst=a[0:nr, lo:hi], data=e,
            op0=nl.multiply, operand0=nl.reciprocal(s), op1=nl.add, operand1=HC_EPS,
        )
    colsum_div(a, b)
    for _ in range(SINKHORN_ITERS - 1):
        rowsum_div(b, a)
        colsum_div(a, b)
    return b


#: `sinkhorn_batched`'s `1 / (sum + eps)` as one ACT instruction (the eps as the reciprocal's
#: bias: the same fp32 sum + eps feeds the function) instead of a copy with the bias and a
#: reciprocal: one ACT instruction fewer on each of the 40 normalizations' serial chain.
SINKHORN_FUSED_EPS = True

#: `sinkhorn_batched`'s row / column scalings as one DVE multiply each, the per-row /
#: per-column factor read with a 0-step access pattern (the rows: no broadcast copy; the
#: columns: one instruction instead of one per row). Elementwise: the same products.
SINKHORN_BCAST_AP = True


def sinkhorn_batched(t2all, nt, hc):
    """`sinkhorn` of `nt` row tiles at once: `t2all` is `(PT, nt, hc*hc)` fp32 (tile `t`'s
    `t2` at `[:, t, :]`), the result likewise. Each element goes through the
    instructions `sinkhorn`'s lowering issues for it (DVE reduce over the 4 columns,
    ACT copy with the eps bias, ACT reciprocal, fp32 DVE multiplies / adds), only with
    all tiles and rows in one instruction instead of one per tile (and row)."""
    if moe_tp.SINKHORN_DVE:
        return moe_tp.sinkhorn_dve(t2all, nt, hc)
    n = nt * hc
    f32 = nl.float32
    x3 = t2all.reshape((PT, n, hc))

    def recip_rows(src3):
        # 1 / (sum over the 4 columns + eps), per (tile, row): (PT, n, 1)
        sm = nl.ndarray((PT, n, 1), dtype=f32, buffer=nl.sbuf)
        nisa.tensor_reduce(dst=sm, op=nl.add, data=src3, axis=(2,), keepdims=True)
        r = nl.ndarray((PT, n, 1), dtype=f32, buffer=nl.sbuf)
        if SINKHORN_FUSED_EPS:
            nisa.activation(dst=r, op=nl.reciprocal, data=sm, bias=HC_EPS, scale=1.0)
            return r
        se = nl.ndarray((PT, n, 1), dtype=f32, buffer=nl.sbuf)
        nisa.activation(dst=se, op=nl.copy, data=sm, bias=HC_EPS, scale=1.0)
        nisa.activation(dst=r, op=nl.reciprocal, data=se)
        return r

    def rowsum_div(src, dst):
        src3 = src.reshape((PT, n, hc))
        r = recip_rows(src3)
        if SINKHORN_BCAST_AP:
            # r read with a 0 step over the 4 columns (no materialized broadcast copy)
            nisa.tensor_tensor(dst=dst.reshape((PT, n, hc)), data1=src3,
                               data2=r.ap(pattern=[[n, PT], [1, n], [0, hc]], offset=0), op=nl.multiply)
            return
        nisa.tensor_tensor(dst=dst.reshape((PT, n, hc)), data1=src3,
                           data2=nl.broadcast_to(r, (PT, n, hc)), op=nl.multiply)

    def colsum_div(src, dst):
        s4 = src.reshape((PT, nt, hc, hc))
        d4 = dst.reshape((PT, nt, hc, hc))
        cs = nl.ndarray((PT, nt, hc), dtype=f32, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=cs, data1=s4[:, :, 0, :], data2=s4[:, :, 1, :], op=nl.add)
        for i in range(2, hc):
            nisa.tensor_tensor(dst=cs, data1=cs, data2=s4[:, :, i, :], op=nl.add)
        d = nl.ndarray((PT, nt, hc), dtype=f32, buffer=nl.sbuf)
        if SINKHORN_FUSED_EPS:
            nisa.activation(dst=d, op=nl.reciprocal, data=cs, bias=HC_EPS, scale=1.0)
        else:
            ce = nl.ndarray((PT, nt, hc), dtype=f32, buffer=nl.sbuf)
            nisa.activation(dst=ce, op=nl.copy, data=cs, bias=HC_EPS, scale=1.0)
            nisa.activation(dst=d, op=nl.reciprocal, data=ce)
        if SINKHORN_BCAST_AP:
            # every row i of each matrix times d in one instruction (d read with a 0 step over i)
            nisa.tensor_tensor(dst=d4, data1=s4,
                               data2=d.ap(pattern=[[nt * hc, PT], [hc, nt], [0, hc], [1, hc]], offset=0),
                               op=nl.multiply)
            return
        for i in range(hc):
            nisa.tensor_tensor(dst=d4[:, :, i, :], data1=s4[:, :, i, :], data2=d, op=nl.multiply)

    a = nl.ndarray((PT, nt, hc * hc), dtype=f32, buffer=nl.sbuf)
    b = nl.ndarray((PT, nt, hc * hc), dtype=f32, buffer=nl.sbuf)
    # softmax over each row's 4 columns, + eps
    mx = nl.ndarray((PT, n, 1), dtype=f32, buffer=nl.sbuf)
    nisa.tensor_reduce(dst=mx, op=nl.max, data=x3, axis=(2,), keepdims=True)
    dif = nl.ndarray((PT, n, hc), dtype=f32, buffer=nl.sbuf)
    mxb = (mx.ap(pattern=[[n, PT], [1, n], [0, hc]], offset=0) if SINKHORN_BCAST_AP
           else nl.broadcast_to(mx, (PT, n, hc)))
    nisa.tensor_tensor(dst=dif, data1=x3, data2=mxb, op=nl.subtract)
    e = nl.ndarray((PT, n, hc), dtype=f32, buffer=nl.sbuf)
    nisa.activation(dst=e, op=nl.exp, data=dif)
    se = nl.ndarray((PT, n, 1), dtype=f32, buffer=nl.sbuf)
    nisa.tensor_reduce(dst=se, op=nl.add, data=e, axis=(2,), keepdims=True)
    re = nl.ndarray((PT, n, 1), dtype=f32, buffer=nl.sbuf)
    nisa.activation(dst=re, op=nl.reciprocal, data=se)
    a3 = a.reshape((PT, n, hc))
    reb = (re.ap(pattern=[[n, PT], [1, n], [0, hc]], offset=0) if SINKHORN_BCAST_AP
           else nl.broadcast_to(re, (PT, n, hc)))
    nisa.tensor_tensor(dst=a3, data1=e, data2=reb, op=nl.multiply)
    nisa.tensor_scalar(dst=a3, data=a3, op0=nl.add, operand0=HC_EPS)
    colsum_div(a, b)
    for _ in range(SINKHORN_ITERS - 1):
        rowsum_div(b, a)
        colsum_div(a, b)
    return b


#: `hc_in` calls run the sinkhorn once over all of the call's row tiles (`sinkhorn_batched`).
HC_SINKHORN_BATCHED = True


def hc_in_consts(base, scale, norm_w, hc, dim, out_chunk=1024, np_=PT, part=None):
    """`hc_in_tile`'s row-invariant operands (`scale`, `base`, `norm_w` rows broadcast
    to `np_` partitions (the call's largest tile), fp32), materialized once for all of a
    call's tiles. `part` (`hc_in_tile`'s): only that part's operands ("x": `norm_w`,
    "c": `scale` / `base`)."""

    def mat(t_hbm, col0, n):
        return bcast_dma(t_hbm, col0, n, np_)

    out = {}
    if part != "x":
        out.update(s0=mat(scale, 0, 1), s1=mat(scale, 1, 1), s2=mat(scale, 2, 1),
                   b0=mat(base, 0, hc), b1=mat(base, hc, hc),
                   b2=mat(base, 2 * hc, hc * hc))
    if part != "c":
        S = hc_in_spread_s(np_, dim) if part == "x" else 1
        if S > 1:
            out["ws"] = (np_, S, bcast_dma_spread(norm_w, np_, dim, S))
        else:
            out["w"] = [mat(norm_w, c * out_chunk, out_chunk) for c in range(dim // out_chunk)]
    return out


#: `hc_in_tile`'s "x" part (pre-mix + RMS norm) at few rows spread over the partitions:
#: partition `s * nr + r` holds columns `[s*w, (s+1)*w)` (w = dim / S) of row `r` (S column
#: blocks, each one affine DMA), so the pre-mix and the norm's scaling run on S times fewer
#: columns (same per-element operations, operands and engines). The norm's sum of squares
#: stays one row-major ACT accumulation chain per row (its fp32 order), on the mixed rows
#: copied back into row layout on chip.
HC_IN_X_SPREAD = True
#: Most column blocks `hc_in_tile`'s spread uses (DMAs per operand).
HC_IN_SPREAD_MAX = 8


def hc_in_spread_s(nr, dim):
    """The spread factor of `hc_in_tile`'s "x" part for an `nr`-row tile (1: not spread)."""
    if not HC_IN_X_SPREAD:
        return 1
    S = 1
    while (S * 2 <= HC_IN_SPREAD_MAX and nr * S * 2 <= PT and dim % (S * 2) == 0
           and dim // (S * 2) >= 64):
        S *= 2
    return S


def bcast_dma_spread(t_hbm, nr, dim, S, dtype=nl.float32):
    """`t_hbm[0, 0:dim]` in `hc_in_tile`'s spread layout: partition `s * nr + r` holds
    columns `[s*w, (s+1)*w)` (the same values as `bcast_dma`)."""
    w = dim // S
    n = nr * S
    raw = nl.ndarray((PT, w), dtype=t_hbm.dtype, buffer=nl.sbuf)
    for s in range(S):
        nisa.dma_copy(dst=raw[s * nr : (s + 1) * nr, :],
                      src=t_hbm.ap(pattern=[[0, nr], [1, w]], offset=s * w))
    if t_hbm.dtype == dtype:
        return raw
    t = nl.ndarray((PT, w), dtype=dtype, buffer=nl.sbuf)
    nisa.tensor_copy(dst=t[0:n, :], src=raw[0:n, :])
    return t


def hc_in_x_spread(r0, nr, x2, pre_mix, norm_w, normed, hc, dim, S, sq_chunk, ws=None, cache=None):
    """`hc_in_tile`'s "x" part (`normed[r0:r0+nr]`) in the spread layout (`HC_IN_X_SPREAD`)."""
    width = hc * dim
    w = dim // S
    n = nr * S
    inv_dim = 1.0 / dim
    if ws is None:
        ws = bcast_dma_spread(norm_w, nr, dim, S)
    xs = nl.ndarray((PT, hc, w), dtype=nl.bfloat16, buffer=nl.sbuf)
    pm = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
    for s in range(S):
        p0 = s * nr
        nisa.dma_copy(dst=xs[p0 : p0 + nr, :, :],
                      src=x2.ap(pattern=[[width, nr], [dim, hc], [1, w]], offset=r0 * width + s * w))
        nisa.dma_copy(dst=pm[p0 : p0 + nr, :], src=pre_mix[r0 : r0 + nr, 0:hc])
    # the pre-mix (`hc_in_tile.premix`'s operations): the first product on ACT, the
    # accumulating ones on DVE, the last writing the bf16 rows
    acc = nl.ndarray((PT, w), dtype=nl.float32, buffer=nl.sbuf)
    ys = nl.ndarray((PT, w), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=acc[0:n, :], data=xs[0:n, 0, :], op0=nl.multiply,
                       operand0=pm[0:n, 0:1], engine=nisa.engine.scalar)
    for g in range(1, hc):
        nisa.scalar_tensor_tensor(
            dst=ys[0:n, :] if g == hc - 1 else acc[0:n, :], data=xs[0:n, g, :], op0=nl.multiply,
            operand0=pm[0:n, g : g + 1], op1=nl.add, operand1=acc[0:n, :],
        )
    if moe_tp.NORM_SPREAD:
        # (`moe_tp.NORM_SPREAD`: the rows' sums of squares and rstd in the spread layout)
        rs = moe_tp.spread_rstd(ys, nr, S, "s", w, NORM_EPS, cache)
    else:
        # the mixed rows in row layout for the sum of squares (row-major chain, as `norm_ss`)
        y16 = nl.ndarray((PT, dim), dtype=nl.bfloat16, buffer=nl.sbuf)
        for s in range(S):
            nisa.dma_copy(dst=y16[0:nr, s * w : (s + 1) * w], src=ys[s * nr : (s + 1) * nr, 0:w])
        ss2 = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        sum_squares(ss2, y16, nr, dim, sq_chunk)
        rstd = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        rstd[0:nr, :] = rsqrt_newton(nl.add(nl.multiply(ss2[0:nr, 0:1], inv_dim), NORM_EPS))
        rs = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        for s in range(S):
            nisa.dma_copy(dst=rs[s * nr : (s + 1) * nr, 0:1], src=rstd[0:nr, 0:1])
    # `norm_chunk`'s operations on the spread rows
    yv = nl.ndarray((PT, w), dtype=nl.float32, buffer=nl.sbuf)
    nisa.activation(dst=yv[0:n, :], op=nl.copy, data=ys[0:n, :], scale=rs[0:n, 0:1])
    o16 = nl.ndarray((PT, w), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.tensor_tensor(dst=o16[0:n, :], data1=yv[0:n, :], data2=ws[0:n, :], op=nl.multiply)
    for s in range(S):
        nisa.dma_copy(dst=normed[r0 : r0 + nr, s * w : (s + 1) * w], src=o16[s * nr : (s + 1) * nr, :])


#: PE transposes per PSUM -> SBUF copy in `hc_in_tile`'s mix GEMM.
HC_T_BATCH = 4
#: `hc_in_tile`'s mix GEMM for a tile of nr <= 128 // HC_T_STACK_MIN rows: J = 128 // nr
#: K-chunks stacked on partitions (loaded by one DMA a row), one PE transpose and one
#: PSUM copy for all J (at nr = 6: 8 transposes instead of 160); the matmuls (stationary
#: values, accumulation order) are unchanged.
HC_T_STACK = True
HC_T_STACK_MIN = 8
#: The fp32 GEMMs whose stationary is bf16 data widened to fp32 (`hc_in_tile`'s mix,
#: `gemm_fp32`) skip the stationary's LOW fp32 pass (`is_stationary_onezero`): the
#: tensor engine splits an fp32 stationary into HIGH and LOW halves and runs one
#: weight load + matmul per half; a bf16 value's LOW half is zero, so that pass only
#: accumulates exact zeros.
FP32_BF16_STATIONARY = True


#: `hc_in_tile` interleaves its pre-mix (DVE) and sum of squares (ACT) with the mix
#: GEMM's transpose copies (all on the other engine meanwhile) instead of issuing them
#: before it (same instructions, program order only).
HC_IN_INTERLEAVE = True
#: With the stacked interleave: the pre-mix, RMS norm and normed-row stores issued right
#: after the first transpose batch, ahead of the mix GEMM's sum of squares (ACT), instead
#: of one piece per batch (the normed rows gate the router / projections; the GEMM's
#: coefficients are first read after the next all-reduce).
HC_IN_XN_FIRST = True
#: `hc_in_tile(part="c")` (the other core's half, no pre-mix on its DVE): every mix-GEMM
#: transpose copy on DVE instead of alternating with ACT, whose queue holds the ~20 us sum of
#: squares chain: an ACT copy behind it stalled the transposes, the stacked loads behind
#: them (buffer reuse) and so that core's sync queue / arrival at the next barrier.
HC_IN_C_COPY_DVE = True
#: HC_IN_C_COPY_DVE only for tiles of at most this many rows.
HC_IN_C_COPY_DVE_MAX_ROWS = 32


def hc_in_tile(r0, nr, x2, pre_mix, fnT, base, scale, norm_w, hc, dim, mix,
               normed, pre, post, comb, sq_chunk=1024, out_chunk=1024, consts=None, xin=None,
               t2_dst=None, part=None, defer=False):
    """One 128-row tile of the hyper-connection sublayer-in (`kernels.hc_in`).

    Reads `x2[r0:r0+nr]` (`[T, hc*dim]` bf16 HBM) and `pre_mix`, writes
    `normed[r0:r0+nr]` (bf16) and the fp32 coefficients `pre`/`post`/`comb`.
    `fnT` is the resident `(PT, nk, mix)` fp32 SBUF copy of `fn.T`; `consts` the
    call's `hc_in_consts` (built here when not given). `xin`: the tile's rows already
    in SBUF (`hc` `(PT, dim)` bf16 tiles, e.g. `hc_out_tile(keep=True)`'s), else they
    are loaded from `x2`. `t2_dst`: a `(PT, hc*hc)` SBUF view that receives the
    pre-sinkhorn comb logits instead of running the sinkhorn and storing `comb` here
    (the caller runs `sinkhorn_batched` over its tiles).
    `part`: only one of the tile's two independent halves (the two cores of a pair can
    each run one, same operations): "x" the pre-mix and the RMS norm (`normed`), "c" the
    sum of squares, the mix GEMM and the coefficients (`pre` / `post` / `comb`).
    `defer` (part "c"): the coefficients (everything after the mix GEMM and the sum of
    squares) are returned as a function for the caller to issue later instead.
    """
    if part == "x" and hc_in_spread_s(nr, dim) > 1:
        S = hc_in_spread_s(nr, dim)
        ws = None
        if consts is not None and "ws" in consts and consts["ws"][:2] == (nr, S):
            ws = consts["ws"][2]
        hc_in_x_spread(r0, nr, x2, pre_mix, norm_w, normed, hc, dim, S, sq_chunk, ws, cache=consts)
        return
    if consts is None:
        consts = hc_in_consts(base, scale, norm_w, hc, dim, out_chunk, part=part)
    width = hc * dim
    kpg = dim // PT
    inv_width = 1.0 / width
    inv_dim = 1.0 / dim

    if xin is not None:
        xg = xin
    else:
        xg = []
        for g in range(hc):
            xg.append(nl.ndarray((PT, dim), dtype=nl.bfloat16, buffer=nl.sbuf))
        for g in range(hc):
            nisa.dma_copy(dst=xg[g][0:nr, :], src=x2[r0 : r0 + nr, g * dim : (g + 1) * dim])
    if part != "c":
        pm = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
        nisa.dma_copy(dst=pm[0:nr, :], src=pre_mix[r0 : r0 + nr, 0:hc])

    if part != "c":
        acc = nl.ndarray((PT, dim), dtype=nl.float32, buffer=nl.sbuf)
        y16 = nl.ndarray((PT, dim), dtype=nl.bfloat16, buffer=nl.sbuf)

    def premix():
        # the first product on ACT (as hc_out's), the accumulating ones on DVE; the last
        # accumulation writes the bf16 rows directly (its fp32 result cast on output, as
        # the separate cast copy did)
        nisa.tensor_scalar(
            dst=acc[0:nr, :], data=xg[0][0:nr, :], op0=nl.multiply,
            operand0=pm[0:nr, 0:1], engine=nisa.engine.scalar,
        )
        for g in range(1, hc):
            nisa.scalar_tensor_tensor(
                dst=y16[0:nr, :] if g == hc - 1 else acc[0:nr, :], data=xg[g][0:nr, :], op0=nl.multiply,
                operand0=pm[0:nr, g : g + 1], op1=nl.add, operand1=acc[0:nr, :],
            )

    if part != "x":
        ss = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        junk = nl.ndarray((PT, sq_chunk), dtype=nl.float32, buffer=nl.sbuf)
    nsq = dim // sq_chunk

    bd_ss = [False]

    def sumsq():
        if bd_ss[0]:
            # (the block-diagonal mix's own sum of squares: `moe_tp.BDMix`)
            return
        # one uninterrupted ACT accumulation chain
        for g in range(hc):
            for c in range(nsq):
                first = g == 0 and c == 0
                last = g == hc - 1 and c == nsq - 1
                nisa.activation(
                    dst=junk[0:nr, :], op=nl.square,
                    data=xg[g][0:nr, c * sq_chunk : (c + 1) * sq_chunk],
                    reduce_op=nl.add,
                    reduce_cmd=nisa.reduce_cmd.reset_reduce if first else nisa.reduce_cmd.reduce,
                    reduce_res=ss[0:nr, 0:1] if last else None,
                )

    if part != "c":
        rstd = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)

    def norm_ss():
        ss2 = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        sum_squares(ss2, y16, nr, dim, sq_chunk)
        rstd[0:nr, :] = rsqrt_newton(nl.add(nl.multiply(ss2[0:nr, 0:1], inv_dim), NORM_EPS))

    def norm_chunk(c):
        lo, hi = c * out_chunk, (c + 1) * out_chunk
        wj = consts["w"][c][0:nr, 0:out_chunk]
        yv = nl.ndarray((PT, out_chunk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=yv[0:nr, :], op=nl.copy, data=y16[0:nr, lo:hi], scale=rstd[0:nr, 0:1])
        o16 = nl.ndarray((PT, out_chunk), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=o16[0:nr, :], data1=yv[0:nr, :], data2=wj, op=nl.multiply)
        nisa.dma_copy(dst=normed[r0 : r0 + nr, lo:hi], src=o16[0:nr, :])

    nout = dim // out_chunk
    if part == "x":
        premix()
        norm_ss()
        for c in range(nout):
            norm_chunk(c)
        return
    if part == "c":
        def premix():
            pass

        def norm_ss():
            pass

        def norm_chunk(c):
            pass

    # stacked: J = 128 // nr K-chunks of a row group's columns on partitions (one per-row
    # DMA from `x2`), one PE transpose for all J (same stationary values)
    # (with `xin`, the rows are read back from `x2`, where the caller stored them)
    J = min(PT // nr, kpg)
    stack = HC_T_STACK and J >= HC_T_STACK_MIN
    sgroups = [(g, c0, min(J, kpg - c0)) for g in range(hc) for c0 in range(0, kpg, J)] if stack else []
    nbatch = len(sgroups) if stack else hc * cdiv(kpg, HC_T_BATCH)
    split = HC_IN_INTERLEAVE and nbatch >= 4 * (nout + 3)
    # interleaved: the pre-mix, the sum of squares and the whole RMS norm of the mixed
    # rows (none needs the mix GEMM) are issued between the GEMM's transpose batches,
    # so they overlap it instead of forming a DVE / ACT stretch between tiles that
    # stalls the next tile's transpose copies (only the coefficients stay after it)
    work = {}
    if stack and HC_IN_INTERLEAVE and nbatch >= nout + 3:
        # one piece of the off-GEMM work after each stacked transpose's copy
        if HC_IN_XN_FIRST:
            # the normed rows' chain first (the next GEMM waits for them; the mix GEMM's
            # coefficients are read much later), then the GEMM's sum of squares
            work = {0: [premix, norm_ss] + [lambda c=c: norm_chunk(c) for c in range(nout)],
                    1: [sumsq]}
        else:
            work = {0: [premix], 1: [sumsq], 2: [norm_ss]}
            for c in range(nout):
                work.setdefault(min(3 + c, nbatch - 1), []).append(lambda c=c: norm_chunk(c))
        split = True
    elif split:
        work[0] = [premix]
        work[2] = [sumsq]
        work[8] = [norm_ss]
        for c in range(nout):
            work.setdefault(12 + 4 * c, []).append(lambda c=c: norm_chunk(c))
    else:
        premix()
        sumsq()

    mixp = nl.ndarray((PT, mix), dtype=nl.float32, buffer=nl.psum)
    bdm = moe_tp.BDMix(nr, mix, consts) if (stack and moe_tp.bd_stack_ok(nr, mix, J)) else None
    bd_ss[0] = bdm is not None
    nbt = 0
    c_copy_dve = part == "c" and HC_IN_C_COPY_DVE and nr <= HC_IN_C_COPY_DVE_MAX_ROWS
    # x2 as 128-column chunks (row r's chunk k at r * (width / 128) + k; a sliced view, so
    # the read is ordered after the caller's stores of the rows)
    x2c = x2.reshape((x2.shape[0] * (width // PT), PT)) if stack else None
    for g, c0, js in sgroups:
        # partition r * js + j = row r's chunk c0 + j of group g (one DMA a row)
        xs = nl.ndarray((PT, PT), dtype=nl.bfloat16, buffer=nl.sbuf)
        for r in range(nr):
            k0 = (r0 + r) * (width // PT) + g * kpg + c0
            nisa.dma_copy(dst=xs[r * js : (r + 1) * js, 0:PT], src=x2c[k0 : k0 + js, 0:PT])
        n = js * nr
        tps = nl.ndarray((PT, PT), dtype=nl.bfloat16, buffer=nl.psum)
        nisa.nc_transpose(dst=tps[0:PT, 0:n], data=xs[0:n, 0:PT])
        # xT[:, j, r] = tps[:, r * js + j]
        xT = nl.ndarray((PT, J, PT // J), dtype=nl.float32, buffer=nl.sbuf)
        eng = (nisa.vector_engine if c_copy_dve
               else nisa.scalar_engine if nbt % 2 else nisa.vector_engine)
        nisa.tensor_copy(dst=xT[0:PT, 0:js, 0:nr],
                         src=tps.ap(pattern=[[PT, PT], [1, js], [js, nr]]), engine=eng)
        for f in work.get(nbt, []):
            f()
        nbt += 1
        if bdm is not None:
            # (`moe_tp.BDMix`: the stacked tile's js K-tiles in one block-diagonal matmul)
            bdm.add(xT.ap(pattern=[[J * (PT // J), PT], [1, js * nr]], offset=0), js, g * kpg + c0, fnT)
            continue
        for j in range(js):
            kb = g * kpg + c0 + j
            nisa.nc_matmul(
                dst=mixp[0:nr, 0:mix], stationary=xT[0:PT, j, 0:nr],
                moving=fnT[0:PT, kb, 0:mix], accumulate=(kb > 0),
                is_stationary_onezero=FP32_BF16_STATIONARY,
            )
    for g in range(0 if stack else hc):
        for cb in range(0, kpg, HC_T_BATCH):
            nb_ = min(HC_T_BATCH, kpg - cb)
            tps = nl.ndarray((PT, HC_T_BATCH, PT), dtype=nl.bfloat16, buffer=nl.psum)
            for j in range(nb_):
                c = cb + j
                nisa.nc_transpose(dst=tps[0:PT, j, 0:nr], data=xg[g][0:nr, c * PT : (c + 1) * PT])
            xT = nl.ndarray((PT, HC_T_BATCH, PT), dtype=nl.float32, buffer=nl.sbuf)
            eng = (nisa.vector_engine if c_copy_dve
                   else nisa.scalar_engine if nbt % 2 else nisa.vector_engine)
            nisa.tensor_copy(dst=xT[0:PT, 0:nb_, 0:nr], src=tps[0:PT, 0:nb_, 0:nr], engine=eng)
            for f in work.get(nbt, []):
                f()
            nbt += 1
            for j in range(nb_):
                kb = g * kpg + cb + j
                nisa.nc_matmul(
                    dst=mixp[0:nr, 0:mix], stationary=xT[0:PT, j, 0:nr],
                    moving=fnT[0:PT, kb, 0:mix], accumulate=(kb > 0),
                    is_stationary_onezero=FP32_BF16_STATIONARY,
                )

    if bdm is not None:
        mixp = bdm.finish(ss)
    def coef():
        rs = rsqrt_newton(nl.add(nl.multiply(ss[0:nr, 0:1], inv_width), NORM_EPS))
        mixv = nl.ndarray((PT, mix), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=mixv[0:nr, :], data=mixp[0:nr, :], op0=nl.multiply, operand0=rs)

        s0 = consts["s0"][0:nr, 0:1]
        s1 = consts["s1"][0:nr, 0:1]
        s2 = consts["s2"][0:nr, 0:1]
        b0 = consts["b0"][0:nr, 0:hc]
        b1 = consts["b1"][0:nr, 0:hc]
        b2 = consts["b2"][0:nr, 0 : hc * hc]

        t0 = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
        nisa.scalar_tensor_tensor(
            dst=t0[0:nr, :], data=mixv[0:nr, 0:hc], op0=nl.multiply, operand0=s0,
            op1=nl.add, operand1=b0,
        )
        pre_t = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
        pre_t[0:nr, :] = nl.add(nl.sigmoid(t0[0:nr, :]), HC_EPS)
        nisa.dma_copy(dst=pre[r0 : r0 + nr, 0:hc], src=pre_t[0:nr, :])

        t1 = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
        nisa.scalar_tensor_tensor(
            dst=t1[0:nr, :], data=mixv[0:nr, hc : 2 * hc], op0=nl.multiply, operand0=s1,
            op1=nl.add, operand1=b1,
        )
        post_t = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
        post_t[0:nr, :] = nl.multiply(nl.sigmoid(t1[0:nr, :]), 2.0)
        nisa.dma_copy(dst=post[r0 : r0 + nr, 0:hc], src=post_t[0:nr, :])

        t2 = nl.ndarray((PT, hc * hc), dtype=nl.float32, buffer=nl.sbuf) if t2_dst is None else t2_dst
        nisa.scalar_tensor_tensor(
            dst=t2[0:nr, :], data=mixv[0:nr, 2 * hc : 2 * hc + hc * hc],
            op0=nl.multiply, operand0=s2, op1=nl.add, operand1=b2,
        )
        if t2_dst is None:
            comb_t = sinkhorn(t2, nr, hc)
            nisa.dma_copy(dst=comb[r0 : r0 + nr, 0 : hc * hc], src=comb_t[0:nr, :])

    if defer and part == "c":
        return coef
    coef()

    if not split:
        norm_ss()
        for c in range(nout):
            norm_chunk(c)


#: `load_fn_t`'s strided load on the sync engine's hardware DGE (off GpSimd).
FN_T_HWDGE = False


def load_fn_t(fn_t, width, mix):
    """`fn.T` (`[hc*dim, mix]` fp32 HBM) resident as `(PT, nk, mix)` fp32 SBUF."""
    nk = width // PT
    fnT = nl.ndarray((PT, nk, mix), dtype=nl.float32, buffer=nl.sbuf)
    if len(fn_t.shape) == 4:
        # (the b1 members' hi | lo bf16 copy, `mk_model.fn_bd`: [p, h, i * 4 + q, c * mix + m] for row
        # k * 128 + p, k = i * nc * 4 + c * 4 + q: rebuilt as hi + lo, ~2^-17 of the fp32 value)
        nq = fn_t.shape[2]
        nc = fn_t.shape[3] // mix
        hl = nl.ndarray((PT, 2, nq, nc * mix), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(dst=hl, src=fn_t, dge_mode=nisa.dge_mode.hwdge, engine=nisa.engine.sync)
        hc = nq // 4
        blk = 2 * nq * nc * mix
        for i in range(hc):
            nisa.tensor_tensor(dst=fnT.ap(pattern=[[nk * mix, PT], [4 * mix, nc], [mix, 4], [1, mix]], offset=i * nc * 4 * mix),
                               data1=hl.ap(pattern=[[blk, PT], [mix, nc], [nc * mix, 4], [1, mix]], offset=i * 4 * nc * mix),
                               data2=hl.ap(pattern=[[blk, PT], [mix, nc], [nc * mix, 4], [1, mix]],
                                           offset=(nq + i * 4) * nc * mix),
                               op=nl.add)
        return fnT
    if len(fn_t.shape) == 3:
        # (the host's tiled copy, `mk_model.hc_fn_map`: one contiguous run a partition)
        nisa.dma_copy(dst=fnT, src=fn_t, dge_mode=nisa.dge_mode.hwdge, engine=nisa.engine.sync)
        return fnT
    if FN_T_HWDGE:
        nisa.dma_copy(dst=fnT, src=fn_t.ap(pattern=[[mix, PT], [PT * mix, nk], [1, mix]]),
                      dge_mode=nisa.dge_mode.hwdge, engine=nisa.engine.sync)
        return fnT
    nisa.dma_copy(dst=fnT, src=fn_t.ap(pattern=[[mix, PT], [PT * mix, nk], [1, mix]]))
    return fnT


#: `hc_out_tile`'s `comb * res` terms `i` (of 1..hc-1) computed as an ACT product plus a
#: GpSimd fp32 add instead of one DVE scalar_tensor_tensor (the same two fp32 roundings).
HC_OUT_OFFLOAD_I = ()


#: At few rows (nr * 4 <= 128) `hc_out_tile` spreads each row over S partitions (S
#: column blocks of dim / S: the same elementwise ops on S times fewer columns), see
#: `hc_out_tile_spread`. Its rows are not kept in SBUF (the caller's `hc_in_tile` reads
#: them back from the output).
HC_OUT_SPREAD = True


def hc_out_spread_s(nr, dim):
    """The spread factor `hc_out_tile` uses for an `nr`-row tile (1: not spread)."""
    if not HC_OUT_SPREAD:
        return 1
    S = 1
    while nr * S * 2 <= PT and dim % (S * 2) == 0 and dim // (S * 2) >= 64:
        S *= 2
    return S if S >= 4 else 1


def hc_out_tile_spread(r0, nr, x_hbm, res_hbm, post_hbm, comb_hbm, y_hbm, hc, dim, S, c0=0, c1=None):
    """`hc_out_tile`'s values with row `r` on partitions `r*S .. r*S + S - 1`, partition
    `r*S + s` holding columns `[s*w, (s+1)*w)` (w = dim / S) of every stream (same
    per-element operations, operands and engines). `c0` / `c1`: only columns [c0, c1) of
    each stream (w = (c1 - c0) / S)."""
    c1 = dim if c1 is None else c1
    full = c0 == 0 and c1 == dim
    width = hc * dim
    dim_full, dim = dim, c1 - c0
    w = dim // S
    n = nr * S
    post = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
    comb = nl.ndarray((PT, hc * hc), dtype=nl.float32, buffer=nl.sbuf)
    rg = nl.ndarray((PT, hc, w), dtype=nl.bfloat16, buffer=nl.sbuf)
    for r in range(nr):
        p0 = r * S
        nisa.dma_copy(dst=post[p0 : p0 + S, :],
                      src=post_hbm.ap(pattern=[[0, S], [1, hc]], offset=(r0 + r) * hc))
        nisa.dma_copy(dst=comb[p0 : p0 + S, :],
                      src=comb_hbm.ap(pattern=[[0, S], [1, hc * hc]], offset=(r0 + r) * hc * hc))
        nisa.dma_copy(dst=rg[p0 : p0 + S, :, :],
                      src=res_hbm.ap(pattern=[[w, S], [dim_full, hc], [1, w]],
                                     offset=(r0 + r) * width + c0))
    acc = nl.ndarray((PT, hc, w), dtype=nl.float32, buffer=nl.sbuf)
    for j in range(hc):
        nisa.tensor_scalar(
            dst=acc[0:n, j, :], data=rg[0:n, 0, :], op0=nl.multiply,
            operand0=comb[0:n, j : j + 1], engine=nisa.engine.scalar,
        )
        for i in range(1, hc):
            col = i * hc + j
            if i in HC_OUT_OFFLOAD_I:
                t = nl.ndarray((PT, w), dtype=nl.float32, buffer=nl.sbuf)
                nisa.tensor_scalar(dst=t[0:n, :], data=rg[0:n, i, :], op0=nl.multiply,
                                   operand0=comb[0:n, col : col + 1], engine=nisa.engine.scalar)
                nisa.tensor_tensor(dst=acc[0:n, j, :], data1=t[0:n, :], data2=acc[0:n, j, :],
                                   op=nl.add, engine=nisa.engine.gpsimd)
                continue
            nisa.scalar_tensor_tensor(
                dst=acc[0:n, j, :], data=rg[0:n, i, :], op0=nl.multiply,
                operand0=comb[0:n, col : col + 1], op1=nl.add, operand1=acc[0:n, j, :],
            )
    # x rows are contiguous: partition r*S + s = flat row r0*S + r*S + s of x as [*, w]
    xg = nl.ndarray((PT, w), dtype=nl.bfloat16, buffer=nl.sbuf)
    if full:
        xv = x_hbm.reshape((x_hbm.shape[0] * S, w))
        nisa.dma_copy(dst=xg[0:n, :], src=xv[r0 * S : r0 * S + n, :])
    else:
        for r in range(nr):
            nisa.dma_copy(dst=xg[r * S : (r + 1) * S, :],
                          src=x_hbm.ap(pattern=[[w, S], [1, w]], offset=(r0 + r) * dim_full + c0))
    og = nl.ndarray((PT, hc, w), dtype=nl.bfloat16, buffer=nl.sbuf)
    for j in range(hc):
        nisa.scalar_tensor_tensor(
            dst=og[0:n, j, :], data=xg[0:n, :], op0=nl.multiply,
            operand0=post[0:n, j : j + 1], op1=nl.add, operand1=acc[0:n, j, :],
        )
    for r in range(nr):
        p0 = r * S
        nisa.dma_copy(dst=y_hbm.ap(pattern=[[w, S], [dim_full, hc], [1, w]],
                                   offset=(r0 + r) * width + c0),
                      src=og[p0 : p0 + S, :, :])


#: At more rows than the spread takes (nr * 4 > 128) but nr * 2 <= 128, `hc_out_tile`
#: block-spreads the tile: partition `s * nr + r` holds columns block `s` of row `r` (S = 2
#: blocks; one affine DMA per block and operand), see `hc_out_tile_bspread`.
HC_OUT_BSPREAD = True
#: `hc_out_tile_bspread`'s columns per partition and instruction (at most).
HC_OUT_BSPREAD_CHUNK = 640


def hc_out_bspread_s(nr, dim):
    """The block-spread factor `hc_out_tile` uses for an `nr`-row tile (1: not spread)."""
    if not HC_OUT_BSPREAD or nr * 2 > PT or dim % 2 or (dim // 2) % 64:
        return 1
    return 2


def hc_out_tile_bspread(r0, nr, x_hbm, res_hbm, post_hbm, comb_hbm, y_hbm, hc, dim, S, c0=0,
                        c1=None):
    """`hc_out_tile`'s values with partition `s * nr + r` holding columns
    `[c0 + s*w, c0 + (s+1)*w)` (w = (c1 - c0) / S) of row `r` of every stream (same
    per-element operations, operands and engines as `hc_out_tile_spread`), in column chunks
    of at most HC_OUT_BSPREAD_CHUNK."""
    c1 = dim if c1 is None else c1
    width = hc * dim
    w = (c1 - c0) // S
    n = nr * S
    nch = cdiv(w, HC_OUT_BSPREAD_CHUNK)
    while w % nch:
        nch += 1
    wc = w // nch
    post = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
    comb = nl.ndarray((PT, hc * hc), dtype=nl.float32, buffer=nl.sbuf)
    for s in range(S):
        p0 = s * nr
        nisa.dma_copy(dst=post[p0 : p0 + nr, :], src=post_hbm[r0 : r0 + nr, 0:hc])
        nisa.dma_copy(dst=comb[p0 : p0 + nr, :], src=comb_hbm[r0 : r0 + nr, 0 : hc * hc])
    for k in range(nch):
        rg = nl.ndarray((PT, hc, wc), dtype=nl.bfloat16, buffer=nl.sbuf)
        for s in range(S):
            nisa.dma_copy(dst=rg[s * nr : (s + 1) * nr, :, :],
                          src=res_hbm.ap(pattern=[[width, nr], [dim, hc], [1, wc]],
                                         offset=r0 * width + c0 + s * w + k * wc))
        acc = nl.ndarray((PT, hc, wc), dtype=nl.float32, buffer=nl.sbuf)
        for j in range(hc):
            nisa.tensor_scalar(
                dst=acc[0:n, j, :], data=rg[0:n, 0, :], op0=nl.multiply,
                operand0=comb[0:n, j : j + 1], engine=nisa.engine.scalar,
            )
            for i in range(1, hc):
                col = i * hc + j
                nisa.scalar_tensor_tensor(
                    dst=acc[0:n, j, :], data=rg[0:n, i, :], op0=nl.multiply,
                    operand0=comb[0:n, col : col + 1], op1=nl.add, operand1=acc[0:n, j, :],
                )
        xg = nl.ndarray((PT, wc), dtype=nl.bfloat16, buffer=nl.sbuf)
        for s in range(S):
            nisa.dma_copy(dst=xg[s * nr : (s + 1) * nr, :],
                          src=x_hbm.ap(pattern=[[dim, nr], [1, wc]],
                                       offset=r0 * dim + c0 + s * w + k * wc))
        og = nl.ndarray((PT, hc, wc), dtype=nl.bfloat16, buffer=nl.sbuf)
        for j in range(hc):
            nisa.scalar_tensor_tensor(
                dst=og[0:n, j, :], data=xg[0:n, :], op0=nl.multiply,
                operand0=post[0:n, j : j + 1], op1=nl.add, operand1=acc[0:n, j, :],
            )
        for s in range(S):
            nisa.dma_copy(dst=y_hbm.ap(pattern=[[width, nr], [dim, hc], [1, wc]],
                                       offset=r0 * width + c0 + s * w + k * wc),
                          src=og[s * nr : (s + 1) * nr, :, :])


def hc_out_tile(r0, nr, x_hbm, res_hbm, post_hbm, comb_hbm, y_hbm, hc, dim, chunk=1024,
                x_dtype=nl.float32, keep=False, acc_first=False, acc_only=False, accs_in=None,
                c0=0, c1=None):
    """One 128-row tile of `hc_post` (`kernels.hc_attn_out`):
    `y[t, j, :] = post[t, j] * x[t, :] + sum_i comb[t, i, j] * res[t, i, :]`.

    `x_hbm` is the sublayer output `[T, dim]` (fp32 or bf16 -- it is widened to fp32
    for the products either way, matching `out.to(x.dtype)` followed by the fp32
    kernel math when `x_dtype` is bf16 and the all-reduced fp32 partial when fp32),
    `res_hbm` the `[T, hc*dim]` bf16 residual stream, `y_hbm` the `[T, hc*dim]` bf16 output.
    `keep`: the output rows also stay in SBUF and are returned (`hc` `(PT, dim)` bf16
    tiles, `hc_in_tile`'s `xin`). `acc_first`: every chunk's `sum_i comb * res` is
    issued before the first `x` load (they do not depend on `x`, e.g. an all-reduce
    result still in flight), then the `post * x` terms. `acc_only`: only those
    accumulators, returned (SBUF); `accs_in`: a previous `acc_only` call's, so only the
    `post * x` terms and the stores run here (a caller pipelines tiles with them).
    `c0` / `c1`: only columns [c0, c1) of each stream (multiples of `chunk`; `keep`'s
    tiles hold only those columns).
    """
    c1 = dim if c1 is None else c1
    S = hc_out_spread_s(nr, c1 - c0)
    Sb = hc_out_bspread_s(nr, c1 - c0) if S == 1 else 1
    if Sb > 1:
        # block-spread (like the spread: nothing kept, `acc_only` defers the whole tile)
        if not acc_only:
            hc_out_tile_bspread(r0, nr, x_hbm, res_hbm, post_hbm, comb_hbm, y_hbm, hc, dim, Sb,
                                c0, c1)
        return None
    if S > 1:
        # spread (returns nothing: `keep` rows are read back from `y_hbm`, `acc_only`
        # defers the whole tile to the `accs_in` call)
        if not acc_only:
            hc_out_tile_spread(r0, nr, x_hbm, res_hbm, post_hbm, comb_hbm, y_hbm, hc, dim, S, c0, c1)
        return None
    assert c0 % chunk == 0 and c1 % chunk == 0
    post = nl.ndarray((PT, hc), dtype=nl.float32, buffer=nl.sbuf)
    nisa.dma_copy(dst=post[0:nr, :], src=post_hbm[r0 : r0 + nr, 0:hc])
    comb = nl.ndarray((PT, hc * hc), dtype=nl.float32, buffer=nl.sbuf)
    nisa.dma_copy(dst=comb[0:nr, :], src=comb_hbm[r0 : r0 + nr, 0 : hc * hc])
    ys = [nl.ndarray((PT, dim), dtype=nl.bfloat16, buffer=nl.sbuf) for _ in range(hc)] if keep else None
    chs = list(range(c0 // chunk, c1 // chunk))

    def acc_of(c):
        col0 = c * chunk
        rg = nl.ndarray((PT, hc, chunk), dtype=nl.bfloat16, buffer=nl.sbuf)
        for i in range(hc):
            nisa.dma_copy(
                dst=rg[0:nr, i, :],
                src=res_hbm[r0 : r0 + nr, i * dim + col0 : i * dim + col0 + chunk],
            )
        acc = nl.ndarray((PT, hc, chunk), dtype=nl.float32, buffer=nl.sbuf)
        for j in range(hc):
            nisa.tensor_scalar(
                dst=acc[0:nr, j, :], data=rg[0:nr, 0, :], op0=nl.multiply,
                operand0=comb[0:nr, j : j + 1], engine=nisa.engine.scalar,
            )
            for i in range(1, hc):
                col = i * hc + j
                if i in HC_OUT_OFFLOAD_I:
                    # the product on ACT, the fp32 add on GpSimd (DVE is the busy engine)
                    t = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
                    nisa.tensor_scalar(dst=t[0:nr, :], data=rg[0:nr, i, :], op0=nl.multiply,
                                       operand0=comb[0:nr, col : col + 1], engine=nisa.engine.scalar)
                    nisa.tensor_tensor(dst=acc[0:nr, j, :], data1=t[0:nr, :], data2=acc[0:nr, j, :],
                                       op=nl.add, engine=nisa.engine.gpsimd)
                    continue
                nisa.scalar_tensor_tensor(
                    dst=acc[0:nr, j, :], data=rg[0:nr, i, :], op0=nl.multiply,
                    operand0=comb[0:nr, col : col + 1], op1=nl.add, operand1=acc[0:nr, j, :],
                )
        return acc

    def out_of(c, acc):
        col0 = c * chunk
        xg = nl.ndarray((PT, chunk), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(dst=xg[0:nr, :], src=x_hbm[r0 : r0 + nr, col0 : col0 + chunk])
        og = None if keep else nl.ndarray((PT, hc, chunk), dtype=nl.bfloat16, buffer=nl.sbuf)

        def og_j(j):
            return ys[j][0:nr, col0 : col0 + chunk] if keep else og[0:nr, j, :]

        for j in range(hc):
            nisa.scalar_tensor_tensor(
                dst=og_j(j), data=xg[0:nr, :], op0=nl.multiply,
                operand0=post[0:nr, j : j + 1], op1=nl.add, operand1=acc[0:nr, j, :],
            )
        for j in range(hc):
            nisa.dma_copy(
                dst=y_hbm[r0 : r0 + nr, j * dim + col0 : j * dim + col0 + chunk],
                src=og_j(j),
            )

    if acc_only:
        return [acc_of(c) for c in chs]
    if accs_in is not None:
        for k, c in enumerate(chs):
            out_of(c, accs_in[k])
    elif acc_first:
        accs = [acc_of(c) for c in chs]
        for k, c in enumerate(chs):
            out_of(c, accs[k])
    else:
        for c in chs:
            out_of(c, acc_of(c))
    return ys


# --------------------------------------------------------------------------- norms, rope, quant


def norm_rows(src_hbm, w_hbm, dst_hbm, tiles, n, qdq, chunk=None):
    """RMSNorm of `src_hbm[r0:r0+nr, 0:n]` (bf16) into `dst_hbm` (bf16) for the given
    row tiles, optionally followed by the fp8 activation round trip (`qdq`).
    """
    chunk = chunk or n
    inv_n = 1.0 / n
    # the weight rows broadcast once, not per row tile
    npart = max([nr for _, nr in tiles], default=0)
    wjs = [bcast_dma(w_hbm, c * chunk, chunk, npart) for c in range(n // chunk)] if npart else []
    for r0, nr in tiles:
        t = nl.ndarray((PT, n), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(dst=t[0:nr, :], src=src_hbm[r0 : r0 + nr, 0:n])
        ss = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        sum_squares(ss, t, nr, n, chunk)
        rstd = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        rstd[0:nr, :] = rsqrt_newton(nl.add(nl.multiply(ss[0:nr, 0:1], inv_n), NORM_EPS))
        y16 = nl.ndarray((PT, n), dtype=nl.bfloat16, buffer=nl.sbuf)
        if qdq and nr < PT:
            nisa.memset(y16, 0.0)
        for c in range(n // chunk):
            lo, hi = c * chunk, (c + 1) * chunk
            wj = wjs[c][0:nr, :]
            yv = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.activation(dst=yv[0:nr, :], op=nl.copy, data=t[0:nr, lo:hi], scale=rstd[0:nr, 0:1])
            nisa.tensor_tensor(dst=y16[0:nr, lo:hi], data1=yv[0:nr, :], data2=wj, op=nl.multiply)
        if qdq:
            out = _qdq_fp8(y16, PT, n)
            nisa.dma_copy(dst=dst_hbm[r0 : r0 + nr, 0:n], src=out[0:nr, :])
        else:
            nisa.dma_copy(dst=dst_hbm[r0 : r0 + nr, 0:n], src=y16[0:nr, :])


def load_freqs(freqs_hbm, row_pos_hbm, r0, nr):
    """`(cos, sin)` fp32 `(PT, 32)` tiles for rows `r0..r0+nr`, gathered from the
    `[max_pos, 64]` (cos | sin) table at the rows' absolute positions.
    """
    pos = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
    nisa.dma_copy(dst=pos[0:nr, :], src=row_pos_hbm[r0 : r0 + nr, 0:1])
    cs = nl.ndarray((PT, 2 * ROPE_HALF), dtype=nl.float32, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=cs[0:nr, :],
        src=freqs_hbm.ap(
            pattern=[[2 * ROPE_HALF, nr], [1, 2 * ROPE_HALF]],
            vector_offset=pos[0:nr, 0:1], indirect_dim=0,
        ),
    )
    return cs[0:nr, 0:ROPE_HALF], cs[0:nr, ROPE_HALF : 2 * ROPE_HALF]


def rope_inplace(tile, nr, col0, cos, sin, inverse):
    """Rotate the `ROPE_DIM` columns at `col0` of the bf16 SBUF `tile` in place,
    adjacent pairs as complex numbers (`model.apply_rotary_emb`). `cos`/`sin` are
    `(nr, 32)` fp32. All four products are formed before either half is written
    back, because `a`/`b` are stride-2 views of the columns being rewritten.
    """
    seg = tile[0:nr, col0 : col0 + ROPE_DIM].reshape((nr, ROPE_HALF, 2))
    a = seg[0:nr, 0:ROPE_HALF, 0]
    b = seg[0:nr, 0:ROPE_HALF, 1]

    def mulf(x, z):
        r = nl.ndarray((PT, ROPE_HALF), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=r[0:nr, :], data1=x, data2=z, op=nl.multiply)
        return r

    ac = mulf(a, cos)
    bs = mulf(b, sin)
    as_ = mulf(a, sin)
    bc = mulf(b, cos)
    o = nl.ndarray((PT, ROPE_HALF, 2), dtype=nl.bfloat16, buffer=nl.sbuf)
    if inverse:
        nisa.tensor_tensor(dst=o[0:nr, :, 0], data1=ac[0:nr, :], data2=bs[0:nr, :], op=nl.add)
        nisa.tensor_tensor(dst=o[0:nr, :, 1], data1=bc[0:nr, :], data2=as_[0:nr, :], op=nl.subtract)
    else:
        nisa.tensor_tensor(dst=o[0:nr, :, 0], data1=ac[0:nr, :], data2=bs[0:nr, :], op=nl.subtract)
        nisa.tensor_tensor(dst=o[0:nr, :, 1], data1=as_[0:nr, :], data2=bc[0:nr, :], op=nl.add)
    nisa.tensor_copy(dst=tile[0:nr, col0 : col0 + ROPE_DIM], src=o[0:nr].reshape((nr, ROPE_DIM)))


def rope_rows(src_hbm, dst_hbm, tiles, width, head, nheads, freqs_hbm, row_pos_hbm,
              inverse, qdq=False):
    """Rope the last `ROPE_DIM` columns of each of `nheads` heads of width `head`
    in `src_hbm[rows, width]` (bf16), optionally fp8-round-trip the rows, and write
    `dst_hbm`. `src_hbm` and `dst_hbm` may be the same tensor.
    """
    for r0, nr in tiles:
        t = nl.ndarray((PT, width), dtype=nl.bfloat16, buffer=nl.sbuf)
        if qdq and nr < PT:
            nisa.memset(t, 0.0)
        nisa.dma_copy(dst=t[0:nr, :], src=src_hbm[r0 : r0 + nr, 0:width])
        cos, sin = load_freqs(freqs_hbm, row_pos_hbm, r0, nr)
        for h in range(nheads):
            rope_inplace(t, nr, h * head + head - ROPE_DIM, cos, sin, inverse)
        if qdq:
            t = _qdq_fp8(t, PT, width)
        nisa.dma_copy(dst=dst_hbm[r0 : r0 + nr, 0:width], src=t[0:nr, :])


# --------------------------------------------------------------------------- GEMMs (fp32 router)


def gemm_fp32(x_hbm, w_t_hbm, out_hbm, tiles, k, n, n0=0):
    """`out[rows, n0 : n0 + n] = x[rows, k] (bf16) @ w_t[k, n0 : n0 + n] (fp32)` with **fp32
    operands** on the tensor engine (the router's `matmul(x.float(), w.float().t())`).
    `w_t` is staged resident as `(PT, k//PT, n)`; `n <= 512`.
    """
    nk = k // PT
    ncol = w_t_hbm.shape[1]
    wT = nl.ndarray((PT, nk, n), dtype=nl.float32, buffer=nl.sbuf)
    nisa.dma_copy(dst=wT, src=w_t_hbm.ap(pattern=[[ncol, PT], [PT * ncol, nk], [1, n]], offset=n0))
    for r0, nr in tiles:
        x = nl.ndarray((PT, k), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(dst=x[0:nr, :], src=x_hbm[r0 : r0 + nr, 0:k])
        acc = nl.ndarray((PT, n), dtype=nl.float32, buffer=nl.psum)
        for kb in range(nk):
            # four transposes per PSUM tile, one copy (bf16 -> fp32, exact) for the four
            if kb % 4 == 0:
                nb_ = min(4, nk - kb)
                tps = nl.ndarray((PT, 4, PT), dtype=nl.bfloat16, buffer=nl.psum)
                for j in range(nb_):
                    nisa.nc_transpose(dst=tps[0:PT, j, 0:nr],
                                      data=x[0:nr, (kb + j) * PT : (kb + j + 1) * PT])
                xT4 = nl.ndarray((PT, 4, PT), dtype=nl.float32, buffer=nl.sbuf)
                nisa.tensor_copy(dst=xT4[0:PT, 0:nb_, 0:nr], src=tps[0:PT, 0:nb_, 0:nr])
            xT = xT4[0:PT, kb % 4, :]
            nisa.nc_matmul(dst=acc[0:nr, 0:n], stationary=xT[0:PT, 0:nr],
                           moving=wT[0:PT, kb, 0:n], accumulate=(kb > 0),
                           is_stationary_onezero=FP32_BF16_STATIONARY)
        o = nl.ndarray((PT, n), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=o[0:nr, :], src=acc[0:nr, :])
        nisa.dma_copy(dst=out_hbm[r0 : r0 + nr, n0 : n0 + n], src=o[0:nr, :])


# --------------------------------------------------------------------------- gathers / scatters


def scatter_rows(src_hbm, slots_hbm, cache_hbm, tiles, n):
    """`cache[slots[r]] = src[r]` for the rows of `tiles` (bf16, `n` columns)."""
    for r0, nr in tiles:
        t = nl.ndarray((PT, n), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(dst=t[0:nr, :], src=src_hbm[r0 : r0 + nr, 0:n])
        ix = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=ix[0:nr, :], src=slots_hbm[r0 : r0 + nr, 0:1])
        nisa.dma_copy(
            dst=cache_hbm.ap(pattern=[[n, nr], [1, n]], vector_offset=ix[0:nr, 0:1], indirect_dim=0),
            src=t[0:nr, :],
        )


def gather_rows(cache_hbm, slots_hbm, dst_hbm, tiles, n, dtype=nl.bfloat16, pair=False, via=None):
    """`dst[r] = cache[slots[r]]` for the rows of `tiles` (`n` columns); `pair`: stored
    in the pair-interleaved column order (`kv_pair_layout`). `via` (an `[R, 1]` int32
    HBM column): `dst[r] = cache[slots[via[r]]]` (the slot looked up by DMA)."""
    for r0, nr in tiles:
        ix = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
        if via is None:
            nisa.dma_copy(dst=ix[0:nr, :], src=slots_hbm[r0 : r0 + nr, 0:1])
        else:
            vi = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
            nisa.dma_copy(dst=vi[0:nr, :], src=via[r0 : r0 + nr, 0:1])
            nisa.dma_copy(
                dst=ix[0:nr, :],
                src=slots_hbm.ap(pattern=[[1, nr], [1, 1]], vector_offset=vi[0:nr, 0:1], indirect_dim=0),
            )
        t = nl.ndarray((PT, n), dtype=dtype, buffer=nl.sbuf)
        nisa.dma_copy(
            dst=t[0:nr, :],
            src=cache_hbm.ap(pattern=[[n, nr], [1, n]], vector_offset=ix[0:nr, 0:1], indirect_dim=0),
        )
        if pair:
            npair = n // (2 * PT)
            tp = nl.ndarray((PT, npair, PT, 2), dtype=dtype, buffer=nl.sbuf)
            nisa.tensor_copy(dst=tp[0:nr, :, :, :],
                             src=t.ap(pattern=[[n, nr], [2 * PT, npair], [1, PT], [PT, 2]]))
            t = tp.reshape((PT, n))
        nisa.dma_copy(dst=dst_hbm[r0 : r0 + nr, 0:n], src=t[0:nr, :])


#: `gather_rows_via`: full 128-row tiles per batched DMA (index load, slot lookup, row
#: gather and store each one DMA for the batch). 8 (1024 indices a DMA) gave wrong rows at
#: in8192_bs10 (max err 3.25); 4 is exact.
GATHER_VIA_BATCH = 4


def gather_rows_via(cache_hbm, slots_hbm, via_hbm, dst_hbm, dst_row0, nrows, pid, n, pair=False,
                    cores=2, batch=None):
    """`dst[dst_row0 + r] = cache[slots[via[r]]]` for rows `r < nrows`, in batches of `G`
    128-row tiles (batch `i` to core `i % cores`) with one DMA each for the index load,
    the slot lookup, the row gather and the store: partition `p`, slot `g` of a batch is
    its row `p * G + g` (contiguous HBM runs; the scratch tensors accessed by slices, so
    their dependencies are tracked). The rows past the last whole batch go through
    `gather_rows` (tiles split like `tiles_of`). `via_hbm` is `[nrows, 1]` int32, `dst_hbm`
    the whole table (`dst_row0` and its row count multiples of `G`)."""
    G = GATHER_VIA_BATCH if batch is None else batch
    # smaller batches when there are few (at least 3 a core, for balance)
    while G > 1 and (nrows // (G * PT) < 3 * cores or nrows % G or dst_row0 % G
                     or dst_hbm.shape[0] % G):
        G //= 2
    nb = nrows // (G * PT)
    via_g = via_hbm.reshape((via_hbm.shape[0] // G, G)) if nb else None
    dst_g = dst_hbm.reshape((dst_hbm.shape[0] // G, G * n)) if nb else None
    for bi in range(pid, nb, cores):
        q0 = bi * PT  # batch bi's rows [bi*G*PT, (bi+1)*G*PT) as PT rows of G
        vi = nl.ndarray((PT, G), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=vi, src=via_g[q0 : q0 + PT, 0:G])
        ix3 = nl.ndarray((PT, G, 1), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=ix3, src=slots_hbm.ap(pattern=[[1, PT * G], [1, 1]], offset=0,
                                                vector_offset=vi, indirect_dim=0))
        t = nl.ndarray((PT, G, n), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(dst=t, src=cache_hbm.ap(pattern=[[n, PT * G], [1, n]], offset=0,
                                              vector_offset=ix3[0:PT, 0:G, 0], indirect_dim=0))
        if pair:
            npair = n // (2 * PT)
            tp = nl.ndarray((PT, G, npair, PT, 2), dtype=nl.bfloat16, buffer=nl.sbuf)
            for g in range(G):
                nisa.tensor_copy(dst=tp[0:PT, g, :, :, :],
                                 src=t.ap(pattern=[[G * n, PT], [2 * PT, npair], [1, PT], [PT, 2]],
                                          offset=g * n))
            out = tp.reshape((PT, G * n))
        else:
            out = t.reshape((PT, G * n))
        d0 = dst_row0 // G + q0
        nisa.dma_copy(dst=dst_g[d0 : d0 + PT, 0 : G * n], src=out[0:PT, 0 : G * n])
    r0 = nb * G * PT
    if r0 < nrows:
        rest = [(r0 + a, b) for a, b in tiles_of(nrows - r0, pid, cores)]
        gather_rows(cache_hbm, slots_hbm, dst_hbm[dst_row0 : dst_row0 + nrows], rest, n, pair=pair,
                    via=via_hbm)


def gather_rows_batched(cache_hbm, slots_hbm, dst_hbm, nrows, pid, n, cores=2, batch=None, row0=0):
    """`dst[r] = cache[slots[r]]` for rows `r < nrows` (`gather_rows` without the per-tile
    `[128, 1]` index loads): the whole 128-row tiles in batches of `G` tiles, core `pid`
    a contiguous run of batches; their slots loaded 128 tiles a DMA (tile `i` on partition
    `i % 128`, 512-byte runs) and PE-transposed on chip (fp32, exact for slots < 2^24, as
    `cmp_gather_onchip`'s), so tile `i`'s index column is column `i % 128`; one gather and
    one store a batch (the hardware reads the indices column-major: destination slot
    `(p, g)` gets the batch's row `p * G + g`). The rows past the last whole batch go
    through `gather_rows` (tiles split like `tiles_of`). `row0`: the rows are
    `row0 .. row0 + nrows` of both `slots_hbm` and `dst_hbm`."""
    G = GATHER_VIA_BATCH if batch is None else batch
    ntl = nrows // PT
    while G > 1 and (ntl // G < 3 * cores or dst_hbm.shape[0] % G or row0 % G):
        G //= 2
    nb = ntl // G
    b_lo = (nb * pid) // cores
    b_hi = (nb * (pid + 1)) // cores
    dst_g = dst_hbm.reshape((dst_hbm.shape[0] // G, G * n)) if nb else None
    bpc = PT // G  # batches a chunk of 128 tiles
    for c0 in range(b_lo, b_hi, bpc):
        cb = min(bpc, b_hi - c0)
        nt = cb * G
        t0 = c0 * G  # first tile of the chunk
        sl = nl.ndarray((PT, PT), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=sl[0:nt, :], src=slots_hbm.ap(pattern=[[PT, nt], [1, PT]], offset=row0 + t0 * PT))
        slf = nl.ndarray((PT, PT), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=slf[0:nt, :], src=sl[0:nt, :])
        tps = nl.ndarray((PT, PT), dtype=nl.float32, buffer=nl.psum)
        nisa.nc_transpose(dst=tps[0:PT, 0:nt], data=slf[0:nt, 0:PT])
        ixT = nl.ndarray((PT, PT), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=ixT[0:PT, 0:nt], src=tps[0:PT, 0:nt])
        for j in range(cb):
            t = nl.ndarray((PT, G, n), dtype=nl.bfloat16, buffer=nl.sbuf)
            nisa.dma_copy(dst=t, src=cache_hbm.ap(pattern=[[n, PT * G], [1, n]], offset=0,
                                                  vector_offset=ixT[0:PT, j * G : (j + 1) * G],
                                                  indirect_dim=0))
            q0 = row0 // G + (c0 + j) * PT
            nisa.dma_copy(dst=dst_g[q0 : q0 + PT, 0 : G * n], src=t.reshape((PT, G * n)))
    r0 = nb * G * PT
    if r0 < nrows:
        rest = [(row0 + r0 + a, b) for a, b in tiles_of(nrows - r0, pid, cores)]
        gather_rows(cache_hbm, slots_hbm, dst_hbm, rest, n)


#: The attention slot table stores each row's 128-column chunks interleaved in pairs,
#: `row'[m*256 + 2i + s] = row[(2m + s)*128 + i]`, so a key tile's transpose is one fp32
#: PE transpose per chunk pair (a bit-exact pass-through costing about what a bf16 one
#: does) instead of one bf16 transpose per chunk; the transposed halves are split back
#: into the chunks by the PSUM -> SBUF copy, and the PV result (over the interleaved
#: columns) is read back in the natural column order by its scaling.
ATTN_PAIR_T = True


def kv_pair_layout(d):
    return ATTN_PAIR_T and (d // PT) % 2 == 0 and d % PT == 0


def key_tile_t(gn, kb, gt, d, eng):
    """`gt[:, c, kb*128 : (kb+1)*128] = gn[:, kb, c*128 : (c+1)*128].T` for every chunk
    `c` (gathered rows `gn` `(PT, ktiles, d)` in the slot table's column order)."""
    dchunks = d // PT
    if kv_pair_layout(d):
        npair = dchunks // 2
        gnf = gn.view(nl.float32)
        tps = nl.ndarray((PT, npair, PT), dtype=nl.float32, buffer=nl.psum)
        for m in range(npair):
            nisa.nc_transpose(dst=tps[0:PT, m, 0:PT], data=gnf[0:PT, kb, m * PT : (m + 1) * PT])
        kpad = gt.shape[2]
        gt4 = gt.reshape((PT, npair, 2, kpad))
        nisa.tensor_copy(dst=gt4[0:PT, 0:npair, 0:2, kb * PT : (kb + 1) * PT],
                         src=tps.ap(pattern=[[npair * PT * 2, PT], [2 * PT, npair], [1, 2], [2, PT]],
                                    dtype=nl.bfloat16),
                         engine=eng)
        return
    tps = nl.ndarray((PT, dchunks, PT), dtype=nl.bfloat16, buffer=nl.psum)
    for c in range(dchunks):
        nisa.nc_transpose(dst=tps[0:PT, c, 0:PT], data=gn[0:PT, kb, c * PT : (c + 1) * PT])
    nisa.tensor_copy(dst=gt[0:PT, 0:dchunks, kb * PT : (kb + 1) * PT], src=tps, engine=eng)


def key_tile_packed(gn, kb, gtp, d, eng):
    """`key_tile_t` keeping the pair layout: `gtp[:, m, kb*128 + k, s]` = chunk `2m + s`
    of key `k` transposed (`(PT, d // 256, kpad, 2)` bf16; one contiguous PSUM copy, the
    score matmuls read a chunk with stride 2)."""
    npair = d // (2 * PT)
    gnf = gn.view(nl.float32)
    tps = nl.ndarray((PT, npair, PT), dtype=nl.float32, buffer=nl.psum)
    first = None
    for m in range(npair):
        ins = nisa.nc_transpose(dst=tps[0:PT, m, 0:PT], data=gnf[0:PT, kb, m * PT : (m + 1) * PT])
        if first is None:
            first = ins
    cp = nisa.tensor_copy(dst=gtp[0:PT, 0:npair, kb * PT : (kb + 1) * PT, 0:2],
                          src=tps.ap(pattern=[[npair * PT * 2, PT], [2 * PT, npair], [2, PT], [1, 2]],
                                     dtype=nl.bfloat16),
                          engine=eng)
    return first, cp


def pv_out(o16, acc_o, rows, rcp, d):
    """`o16[0:rows] = acc_o * rcp` (bf16) with the PV result's columns (the slot table's
    column order) back in the natural order."""
    if kv_pair_layout(d):
        npair = d // (2 * PT)
        o4 = o16.reshape((o16.shape[0], npair, 2, PT))
        nisa.tensor_scalar(dst=o4[0:rows, :, :, :],
                           data=acc_o.ap(pattern=[[d, rows], [2 * PT, npair], [1, 2], [2, PT]]),
                           op0=nl.multiply, operand0=rcp)
        return
    nisa.tensor_scalar(dst=o16[0:rows, :], data=acc_o[0:rows, :], op0=nl.multiply, operand0=rcp)


# --------------------------------------------------------------------------- sparse attention


def _load_col_f32(col_hbm, r0, nr):
    """An int32 `[T, 1]` host column as an fp32 `(PT, 1)` SBUF tile (rows r0..r0+nr)."""
    ci = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
    nisa.dma_copy(dst=ci[0:nr, :], src=col_hbm[r0 : r0 + nr, 0:1])
    cf = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_copy(dst=cf[0:nr, :], src=ci[0:nr, :])
    return cf


def _span_of(cb, nr, nspans, nspan_rows, nwin):
    """fp32 `(PT, 1)`: the span `b` of rows whose compressed base (`cbase`, fp32 `cb`) is
    `b * nspan_rows + nwin`, counted exactly: #{s in 1..nspans-1 : cb >= s*nspan_rows + nwin}."""
    b = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
    if nspans <= 1:
        nisa.memset(b[0:nr, :], 0.0)
        return b
    ns = nspans - 1
    thi = nl.ndarray((PT, ns), dtype=nl.int32, buffer=nl.sbuf)
    nisa.iota(dst=thi[0:nr, :], pattern=[[nspan_rows, ns]], offset=nspan_rows + nwin, channel_multiplier=0)
    th = nl.ndarray((PT, ns), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_copy(dst=th[0:nr, :], src=thi[0:nr, :])
    ge = nl.ndarray((PT, ns), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=ge[0:nr, :], data=th[0:nr, :], op0=nl.less_equal, operand0=cb[0:nr, 0:1])
    nisa.tensor_reduce(dst=b[0:nr, :], op=nl.add, data=ge[0:nr, :], axis=1, keepdims=True)
    return b


#: `cmp_compose_index` with `slots_hbm`: span tables of at most this many entries are
#: looked up on chip (`nc_n_gather` from each row's span table, loaded by one DMA a row
#: tile) instead of by one 4-byte indirect DMA a 128-row gather tile.
CMP_SLOTS_ON_CHIP_MAX = 12288


#: `cmp_gather_onchip`'s row gathers: G consecutive 128-row tiles per 2-D vector-offset
#: DMA (1 = one indirect DMA a tile).
CMP_GATHER_BATCH = 4


def cmp_gather_onchip(cache_hbm, slots_hbm, dst_hbm, dst_row0, T, cbase, topk_hbm, topk, nspans,
                      nspan_rows, nwin, read_len, pid, n, pair=False, cores=2):
    """`dst[dst_row0 + r * topk + j] = cache[cmp_slots[b(r) * read_len + max(topk[r, j], 0)]]` for the
    128-row tiles of `T * topk` rows that core `pid` owns (`tiles_of`), the slot lookups
    done on chip (`cmp_compose_index(slots_hbm=...)`'s values) and the gather indices
    kept in SBUF: tile `i` = row `i // (topk / 128)`'s columns `(i % (topk / 128)) * 128 ..`,
    its index column one PE transpose (fp32, exact for row ids < 2^24) of those columns.
    Needs `topk % 128 == 0`."""
    nc = topk // PT
    mine = [i for i in range(T * nc) if i % cores == pid]
    for g0 in range(0, T, PT):
        gr = min(PT, T - g0)
        gt = [i for i in mine if g0 * nc <= i < (g0 + gr) * nc]
        if not gt:
            continue
        cb = _load_col_f32(cbase, g0, gr)
        b = _span_of(cb, gr, nspans, nspan_rows, nwin)
        bi = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=bi[0:gr, :], src=b[0:gr, :])
        stab = nl.ndarray((PT, read_len), dtype=nl.int32, buffer=nl.sbuf)
        s2 = slots_hbm.reshape((nspans, read_len))
        nisa.dma_copy(dst=stab[0:gr, :],
                      src=s2.ap(pattern=[[read_len, gr], [1, read_len]], offset=0,
                                vector_offset=bi[0:gr, 0:1], indirect_dim=0))
        tki = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=tki[0:gr, :], src=topk_hbm[g0 : g0 + gr, 0:topk])
        tk = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=tk[0:gr, :], src=tki[0:gr, :])
        nisa.tensor_scalar(dst=tk[0:gr, :], data=tk[0:gr, :], op0=nl.maximum, operand0=0.0)
        tku = nl.ndarray((PT, topk), dtype=nl.uint32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=tku[0:gr, :], src=tk[0:gr, :])
        sl = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
        nisa.nc_n_gather(dst=sl[0:gr, :], data=stab[0:gr, :], indices=tku[0:gr, :])
        slf = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=slf[0:gr, :], src=sl[0:gr, :])
        # ixa[p, r, c] = sl[r, c * 128 + p]: the gather index column of tile (g0 + r) * nc + c
        ixa = nl.ndarray((PT, PT, nc), dtype=nl.int32, buffer=nl.sbuf)
        for c in range(nc):
            tps = nl.ndarray((PT, PT), dtype=nl.float32, buffer=nl.psum)
            nisa.nc_transpose(dst=tps[0:PT, 0:gr], data=slf[0:gr, c * PT : (c + 1) * PT])
            nisa.tensor_copy(dst=ixa[0:PT, 0:gr, c], src=tps[0:PT, 0:gr])
        G = CMP_GATHER_BATCH
        if G > 1:
            # batches of G consecutive tiles (batch b to core b % cores) by one 2-D gather:
            # index column q of the batch = its tile q's, so destination slot (p, g) gets
            # the batch's row p * G + g (the hardware reads the indices column-major and
            # writes the rows in order) and the batch stores as one contiguous block
            ixf = ixa.reshape((PT, PT * nc))
            nb_g = (gr * nc) // G
            assert dst_row0 % G == 0 and dst_hbm.shape[0] % G == 0
            kv_g = dst_hbm.reshape((dst_hbm.shape[0] // G, G * n))
            for bb in range(nb_g):
                if (g0 * nc // G + bb) % cores != pid:
                    continue
                t = nl.ndarray((PT, G, n), dtype=nl.bfloat16, buffer=nl.sbuf)
                nisa.dma_copy(dst=t, src=cache_hbm.ap(pattern=[[n, PT * G], [1, n]], offset=0,
                                                      vector_offset=ixf[0:PT, bb * G : (bb + 1) * G],
                                                      indirect_dim=0))
                if pair:
                    npair = n // (2 * PT)
                    tp = nl.ndarray((PT, G, npair, PT, 2), dtype=nl.bfloat16, buffer=nl.sbuf)
                    for g in range(G):
                        nisa.tensor_copy(dst=tp[0:PT, g, :, :, :],
                                         src=t.ap(pattern=[[G * n, PT], [2 * PT, npair], [1, PT], [PT, 2]],
                                                  offset=g * n))
                    out = tp.reshape((PT, G * n))
                else:
                    out = t.reshape((PT, G * n))
                q0 = (dst_row0 + (g0 * nc + bb * G) * PT) // G
                nisa.dma_copy(dst=kv_g[q0 : q0 + PT, 0 : G * n], src=out[0:PT, 0 : G * n])
            # the tiles past the last whole batch one by one (alternating cores)
            gt = [i for i in range(g0 * nc + nb_g * G, (g0 + gr) * nc) if i % cores == pid]
        for i in gt:
            r, c = i // nc - g0, i % nc
            t = nl.ndarray((PT, n), dtype=nl.bfloat16, buffer=nl.sbuf)
            nisa.dma_copy(
                dst=t[0:PT, :],
                src=cache_hbm.ap(pattern=[[n, PT], [1, n]], vector_offset=ixa[0:PT, r, c : c + 1],
                                 indirect_dim=0),
            )
            if pair:
                npair = n // (2 * PT)
                tp = nl.ndarray((PT, npair, PT, 2), dtype=nl.bfloat16, buffer=nl.sbuf)
                nisa.tensor_copy(dst=tp[0:PT, :, :, :],
                                 src=t.ap(pattern=[[n, PT], [2 * PT, npair], [1, PT], [PT, 2]]))
                t = tp.reshape((PT, n))
            d0 = dst_row0 + i * PT
            nisa.dma_copy(dst=dst_hbm[d0 : d0 + PT, 0:n], src=t[0:PT, :])


def cmp_compose_index(cix_hbm, T, cbase, topk_hbm, topk, nspans, nspan_rows, nwin, read_len,
                      slots_hbm=None):
    """The compact slot table's compressed-row sources (every row r < T, on the calling
    core): `cix[r, j] = b(r) * read_len + max(topk[r, j], 0)`, the `cmp_slots` row its row
    `r * topk + j` is gathered from (`b(r)` = row r's span; an empty slot reads the span's
    first row, never attended to). With `slots_hbm` (`cmp_slots`, `[nspans * read_len, 1]`):
    the looked-up cache rows themselves, `cix[r, j] = cmp_slots[b(r) * read_len + max(topk[r, j], 0)]`."""
    for r0 in range(0, T, PT):
        nr = min(PT, T - r0)
        cb = _load_col_f32(cbase, r0, nr)
        b = _span_of(cb, nr, nspans, nspan_rows, nwin)
        if slots_hbm is not None:
            # row r's span table cmp_slots[b(r) * read_len ...] on its partition (one
            # indirect DMA), then the top-k entries picked on chip
            bi = nl.ndarray((PT, 1), dtype=nl.int32, buffer=nl.sbuf)
            nisa.tensor_copy(dst=bi[0:nr, :], src=b[0:nr, :])
            stab = nl.ndarray((PT, read_len), dtype=nl.int32, buffer=nl.sbuf)
            s2 = slots_hbm.reshape((nspans, read_len))
            nisa.dma_copy(dst=stab[0:nr, :],
                          src=s2.ap(pattern=[[read_len, nr], [1, read_len]], offset=0,
                                    vector_offset=bi[0:nr, 0:1], indirect_dim=0))
            tki = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
            nisa.dma_copy(dst=tki[0:nr, :], src=topk_hbm[r0 : r0 + nr, 0:topk])
            tk = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_copy(dst=tk[0:nr, :], src=tki[0:nr, :])
            nisa.tensor_scalar(dst=tk[0:nr, :], data=tk[0:nr, :], op0=nl.maximum, operand0=0.0)
            tku = nl.ndarray((PT, topk), dtype=nl.uint32, buffer=nl.sbuf)
            nisa.tensor_copy(dst=tku[0:nr, :], src=tk[0:nr, :])
            sl = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
            nisa.nc_n_gather(dst=sl[0:nr, :], data=stab[0:nr, :], indices=tku[0:nr, :])
            nisa.dma_copy(dst=cix_hbm[r0 : r0 + nr, 0:topk], src=sl[0:nr, :])
            continue
        boff = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=boff[0:nr, :], data=b[0:nr, :], op0=nl.multiply, operand0=float(read_len))
        tki = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=tki[0:nr, :], src=topk_hbm[r0 : r0 + nr, 0:topk])
        tk = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=tk[0:nr, :], src=tki[0:nr, :])
        nisa.tensor_scalar(dst=tk[0:nr, :], data=tk[0:nr, :], op0=nl.maximum, operand0=0.0)
        nisa.tensor_scalar(dst=tk[0:nr, :], data=tk[0:nr, :], op0=nl.add, operand0=boff[0:nr, 0:1])
        ci = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=ci[0:nr, :], src=tk[0:nr, :])
        nisa.dma_copy(dst=cix_hbm[r0 : r0 + nr, 0:topk], src=ci[0:nr, :])


def attn_index_table(idx_hbm, tiles, twin, wv, win, cbase, topk_hbm, topk, kpad, idxp_hbm=None,
                     zrow0=None, compact=None):
    """Build the per-row slot index table `idx_hbm[T, kpad]` (int32, -1 = empty):

        idx[r, j]         = twin[r] + j         if wv[r] + j >= 0 else -1   (j < win)
        idx[r, win + j]   = cbase[r] + topk[r, j]  if topk[r, j] >= 0 else -1
        idx[r, win+topk:] = -1

    `twin`, `wv`, `cbase` are `[T, 1]` int32 host columns (table row of the first
    window slot, window validity base, table row of the first compressed slot).

    `idxp_hbm` (optional) gets the same rows permuted for the batched gather
    (`gather_index_p`): `idxp[r, p * kt + m] = idx[r, m * 128 + p]`, `kt = kpad / 128`.
    With `zrow0`, an empty slot of `idxp` is `zrow0 + p` instead of -1: one of 128 zero
    rows of the slot table, so the masked slots of a gather do not all read one row.
    `idxp_hbm` is stored transposed per row (`[r, a * kt + q] = idxp[r, q * 128 + a]`,
    see below), so `attn_step` loads a token's gather index contiguously.

    `compact = (nspans, nspan_rows, nwin, read_len, cmp0)`: the compact slot table (span
    b's window rows at `b * nwin`, row r's top-k compressed rows at `cmp0 + r * topk`,
    `cmp_compose_index`) instead of `nspan_rows` rows a span: the window part is
    `twin[r] - b(r) * read_len + j`, the compressed part `cmp0 + r * topk + j` (the same
    keys in the same order).
    """
    ktiles = kpad // PT
    for r0, nr in tiles:
        row = nl.ndarray((PT, kpad), dtype=nl.float32, buffer=nl.sbuf)
        j = nl.ndarray((PT, win), dtype=nl.int32, buffer=nl.sbuf)
        nisa.iota(dst=j[0:nr, :], pattern=[[1, win]], offset=0, channel_multiplier=0)
        jf = nl.ndarray((PT, win), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=jf[0:nr, :], src=j[0:nr, :])
        tw = _load_col_f32(twin, r0, nr)
        if compact is not None:
            c_nspans, c_nspan_rows, c_nwin, c_read_len, c_cmp0 = compact
            cbk = _load_col_f32(cbase, r0, nr)
            bsp = _span_of(cbk, nr, c_nspans, c_nspan_rows, c_nwin)
            nisa.tensor_scalar(dst=bsp[0:nr, :], data=bsp[0:nr, :], op0=nl.multiply,
                               operand0=-float(c_read_len))
            nisa.tensor_tensor(dst=tw[0:nr, :], data1=tw[0:nr, :], data2=bsp[0:nr, :], op=nl.add)
        wvc = _load_col_f32(wv, r0, nr)
        # valid = (j + wv >= 0) as 0/1
        valid = nl.ndarray((PT, win), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=valid[0:nr, :], data=jf[0:nr, :], op0=nl.add, operand0=wvc[0:nr, 0:1],
                           op1=nl.greater_equal, operand1=0.0)
        # idx = (j + tw) * valid + (valid - 1)
        base = nl.ndarray((PT, win), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=base[0:nr, :], data=jf[0:nr, :], op0=nl.add, operand0=tw[0:nr, 0:1])
        nisa.tensor_tensor(dst=base[0:nr, :], data1=base[0:nr, :], data2=valid[0:nr, :], op=nl.multiply)
        vm1 = nl.ndarray((PT, win), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=vm1[0:nr, :], data=valid[0:nr, :], op0=nl.add, operand0=-1.0)
        nisa.tensor_tensor(dst=row[0:nr, 0:win], data1=base[0:nr, :], data2=vm1[0:nr, :], op=nl.add)
        if topk:
            tki = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
            nisa.dma_copy(dst=tki[0:nr, :], src=topk_hbm[r0 : r0 + nr, 0:topk])
            tk = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_copy(dst=tk[0:nr, :], src=tki[0:nr, :])
            cb = _load_col_f32(cbase, r0, nr)
            tv = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_scalar(dst=tv[0:nr, :], data=tk[0:nr, :], op0=nl.greater_equal, operand0=0.0)
            tb = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
            if compact is not None:
                # cmp0 + r * topk + j
                tbi = nl.ndarray((PT, topk), dtype=nl.int32, buffer=nl.sbuf)
                nisa.iota(dst=tbi[0:nr, :], pattern=[[1, topk]], offset=c_cmp0 + r0 * topk,
                          channel_multiplier=topk)
                nisa.tensor_copy(dst=tb[0:nr, :], src=tbi[0:nr, :])
            else:
                nisa.tensor_scalar(dst=tb[0:nr, :], data=tk[0:nr, :], op0=nl.add, operand0=cb[0:nr, 0:1])
            nisa.tensor_tensor(dst=tb[0:nr, :], data1=tb[0:nr, :], data2=tv[0:nr, :], op=nl.multiply)
            tm1 = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_scalar(dst=tm1[0:nr, :], data=tv[0:nr, :], op0=nl.add, operand0=-1.0)
            nisa.tensor_tensor(dst=row[0:nr, win : win + topk], data1=tb[0:nr, :], data2=tm1[0:nr, :], op=nl.add)
        if kpad > win + topk:
            nisa.memset(row[0:nr, win + topk : kpad], -1.0)
        irow = nl.ndarray((PT, kpad), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=irow[0:nr, :], src=row[0:nr, :])
        nisa.dma_copy(dst=idx_hbm[r0 : r0 + nr, 0:kpad], src=irow[0:nr, :])
        if idxp_hbm is not None:
            prow = nl.ndarray((PT, PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
            if zrow0 is None:
                for m in range(ktiles):
                    nisa.tensor_copy(dst=prow[0:nr, :, m], src=irow[0:nr, m * PT : (m + 1) * PT])
            else:
                # empty (-1) -> zrow0 + p: row + (row < 0) * (zrow0 + 1 + p), exact in fp32
                zp = nl.ndarray((PT, PT), dtype=nl.int32, buffer=nl.sbuf)
                nisa.iota(dst=zp[0:nr, :], pattern=[[1, PT]], offset=zrow0 + 1, channel_multiplier=0)
                zpf = nl.ndarray((PT, PT), dtype=nl.float32, buffer=nl.sbuf)
                nisa.tensor_copy(dst=zpf[0:nr, :], src=zp[0:nr, :])
                for m in range(ktiles):
                    c0, c1 = m * PT, (m + 1) * PT
                    neg = nl.ndarray((PT, PT), dtype=nl.float32, buffer=nl.sbuf)
                    nisa.tensor_scalar(dst=neg[0:nr, :], data=row[0:nr, c0:c1], op0=nl.less, operand0=0.0)
                    nisa.tensor_tensor(dst=neg[0:nr, :], data1=neg[0:nr, :], data2=zpf[0:nr, :], op=nl.multiply)
                    nisa.tensor_tensor(dst=neg[0:nr, :], data1=neg[0:nr, :], data2=row[0:nr, c0:c1], op=nl.add)
                    nisa.tensor_copy(dst=prow[0:nr, :, m], src=neg[0:nr, :])
            # stored transposed as `(128, kt)` per row: the gather's `(128, kt)` index tile
            # (read column-major) is then one contiguous run per partition,
            # `idxp_t[r, a * kt + q] = idxp[r, q * 128 + a]`
            pq = prow.reshape((PT, ktiles, PT))
            xrow = nl.ndarray((PT, PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
            for q in range(ktiles):
                nisa.tensor_copy(dst=xrow[0:nr, :, q], src=pq[0:nr, q, :])
            nisa.dma_copy(dst=idxp_hbm.reshape((idxp_hbm.shape[0], PT, ktiles))[r0 : r0 + nr, :, :],
                          src=xrow[0:nr, :, :])


def _ktile(k):
    if k <= PSUM_FP32:
        return k
    for cand in (PSUM_FP32, 256, PT):
        if k % cand == 0:
            return cand
    return PT


def _align16(n):
    return -(-n // 16) * 16


def attn_token_body(i, tok0, q_hbm, kvtab_hbm, idx_hbm, o_hbm, sink_t, heads, d, kpad, scale):
    """Sparse attention for token `tok0 + i` (`i` a loop register): the algorithm of
    `kernels.sparse_attn.gathered_attn_idx`, with the empty-slot bias built here.

    `q_hbm`/`o_hbm` are `[Tp, heads*d]` bf16, `kvtab_hbm` the `[rows, d]` bf16 slot
    table, `idx_hbm` `[Tp, kpad]` int32 (-1 = empty), `sink_t` `(heads, 1)` fp32 SBUF.
    """
    dchunks = d // PT
    ktiles = kpad // PT
    kt = _ktile(kpad)
    ntiles = kpad // kt
    hp = _align16(heads)
    hw = heads * d

    # This token's slot indices, twice: (PT, ktiles) for the gather, (1, kpad) for the bias.
    ids = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=ids,
        src=idx_hbm.ap(pattern=[[1, PT], [PT, ktiles]], offset=tok0 * kpad,
                       scalar_offset=i, indirect_dim=0),
    )
    gidx = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=gidx, data=ids, op0=nl.maximum, operand0=0.0)
    idrow = nl.ndarray((1, kpad), dtype=nl.float32, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=idrow,
        src=idx_hbm.ap(pattern=[[kpad, 1], [1, kpad]], offset=tok0 * kpad,
                       scalar_offset=i, indirect_dim=0),
    )
    # bias = (idx < 0) * NEG_BOUND, broadcast over the heads.
    brow = nl.ndarray((1, kpad), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=brow, data=idrow, op0=nl.less, operand0=0.0,
                       op1=nl.multiply, operand1=NEG_BOUND)
    bias_b = nl.broadcast_to(brow, (heads, kpad))

    # q rows of this token: (heads, d) -> transposed (PT, dchunks, heads) on the PE.
    qrow = nl.ndarray((hp, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=qrow[0:heads, :],
        src=q_hbm.ap(pattern=[[d, heads], [1, d]], offset=tok0 * hw, scalar_offset=i, indirect_dim=0),
    )
    qt = nl.ndarray((PT, dchunks, hp), dtype=nl.bfloat16, buffer=nl.sbuf)
    for c in range(dchunks):
        qps = nl.ndarray((PT, hp), dtype=nl.bfloat16, buffer=nl.psum)
        nisa.nc_transpose(dst=qps[0:PT, 0:heads], data=qrow[0:heads, c * PT : (c + 1) * PT])
        nisa.tensor_copy(dst=qt[0:PT, c, 0:heads], src=qps[0:PT, 0:heads])

    gt = nl.ndarray((PT, dchunks, kpad), dtype=nl.bfloat16, buffer=nl.sbuf)
    gn = nl.ndarray((PT, ktiles, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    for kb in range(ktiles):
        nisa.dma_copy(
            dst=gn[0:PT, kb, 0:d],
            src=kvtab_hbm.ap(pattern=[[d, PT], [1, d]], offset=0,
                             vector_offset=gidx[0:PT, kb : kb + 1], indirect_dim=0),
        )
        key_tile_t(gn, kb, gt, d, nisa.engine.unknown)

    sc = nl.ndarray((heads, kpad), dtype=nl.float32, buffer=nl.sbuf)
    for nb in range(ntiles):
        acc = nl.ndarray((heads, kt), dtype=nl.float32, buffer=nl.psum)
        for c in range(dchunks):
            nisa.nc_matmul(
                dst=acc, stationary=qt[0:PT, c, 0:heads],
                moving=gt[0:PT, c, nb * kt : (nb + 1) * kt], accumulate=(c > 0),
            )
        nisa.scalar_tensor_tensor(
            dst=sc[0:heads, nb * kt : (nb + 1) * kt], data=acc, op0=nl.multiply, operand0=scale,
            op1=nl.add, operand1=bias_b[0:heads, nb * kt : (nb + 1) * kt],
        )

    neg_max = nl.negative(nl.max(sc[0:heads, 0:kpad], axis=1, keepdims=True))
    p32 = nl.ndarray((heads, kpad), dtype=nl.float32, buffer=nl.sbuf)
    den = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.activation(dst=p32, op=nl.exp, data=sc[0:heads, 0:kpad], bias=neg_max, scale=1.0,
                    reduce_op=nl.add, reduce_res=den)
    sk = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.activation(dst=sk, op=nl.exp, data=sink_t, bias=neg_max)
    rcp = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.reciprocal(dst=rcp, data=nl.add(den, sk))
    p16 = nl.copy(p32, dtype=nl.bfloat16)

    pt = nl.ndarray((PT, ktiles, hp), dtype=nl.bfloat16, buffer=nl.sbuf)
    for kb in range(ktiles):
        ptps = nl.ndarray((PT, hp), dtype=nl.bfloat16, buffer=nl.psum)
        nisa.nc_transpose(dst=ptps[0:PT, 0:heads], data=p16[0:heads, kb * PT : (kb + 1) * PT])
        nisa.tensor_copy(dst=pt[0:PT, kb, 0:heads], src=ptps[0:PT, 0:heads])
    acc_o = nl.ndarray((heads, d), dtype=nl.float32, buffer=nl.psum)
    for kb in range(ktiles):
        nisa.nc_matmul(dst=acc_o, stationary=pt[0:PT, kb, 0:heads], moving=gn[0:PT, kb, 0:d],
                       accumulate=(kb > 0))
    o16 = nl.ndarray((hp, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    pv_out(o16, acc_o, heads, rcp, d)
    nisa.dma_copy(
        dst=o_hbm.ap(pattern=[[d, heads], [1, d]], offset=tok0 * hw, scalar_offset=i, indirect_dim=0),
        src=o16[0:heads, :],
    )


#: SBUF bytes a partition may hold of the resident transposed key table
#: (`build_kT`): 4 chunks x 2 bytes x rows, so 96 KiB covers 12288 slot-table rows.
KT_SBUF_BYTES = 96 * 1024
#: The widest tensor a tensor-indirect matmul operand may read (NCC_IBIR039).
TI_MAX_COLS = 4096


def kt_resident(ntab, hd):
    """Whether a slot table of `ntab` rows fits the resident transposed layout
    (the per-partition cost: `hd // 128` chunks of `pad_to(ntab, 128)` bf16)."""
    ntab_p = pad_to(ntab, PT)
    return (hd // PT) * ntab_p * 2 <= KT_SBUF_BYTES and ntab_p <= TI_MAX_COLS


def _ti_block(kpad):
    """Score-block width of the resident path: the widest multiple of 16 that
    divides `kpad` and fits one PSUM bank."""
    for cand in range(PSUM_FP32, 0, -16):
        if kpad % cand == 0:
            return cand
    return 16


def build_kT(kvtab_hbm, ntab, hd):
    """The slot table transposed and resident: one SBUF tensor per 128-wide head-dim
    chunk, `kT[c][d, r] = kvtab[r, c*128 + d]` (bf16), built with DMA transposes.
    `kvtab_hbm` has at least `pad_to(ntab, 128)` rows."""
    ntab_p = pad_to(ntab, PT)
    kTs = []
    for c in range(hd // PT):
        kT = nl.ndarray((PT, ntab_p), dtype=nl.bfloat16, buffer=nl.sbuf)
        for r0 in range(0, ntab_p, PT):
            nisa.dma_transpose(dst=kT[0:PT, r0 : r0 + PT], src=kvtab_hbm[r0 : r0 + PT, c * PT : (c + 1) * PT])
        kTs.append(kT)
    return kTs


def ti_score_psum(heads, kpad):
    """The resident path's score accumulators, one PSUM bank-sized block each. A
    tensor-indirect matmul's destination is loop-carried for the compiler, so these
    are allocated outside the token loop."""
    kb = _ti_block(kpad)
    return [nl.ndarray((heads, kb), dtype=nl.float32, buffer=nl.psum) for _ in range(kpad // kb)]


def attn_token_body_ti(i, tok0, q_hbm, kvtab_hbm, kTs, accs, idx_hbm, o_hbm, sink_t, heads, d, kpad,
                       scale):
    """`attn_token_body` with the keys selected on chip: the score matmuls read the
    token's `kpad` columns of the resident `kTs` through tensor indirection (the
    slot indices in the 16-partition snake the tensor engine reads, replicated into
    each quadrant), so no per-token transposes; the values are still gathered from
    `kvtab_hbm` by indirect DMA for the PV matmul."""
    dchunks = d // PT
    ktiles = kpad // PT
    bw = _ti_block(kpad)
    nblk = kpad // bw
    ncol = bw // 16
    hp = _align16(heads)
    hw = heads * d

    ids = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=ids,
        src=idx_hbm.ap(pattern=[[1, PT], [PT, ktiles]], offset=tok0 * kpad,
                       scalar_offset=i, indirect_dim=0),
    )
    gidx = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=gidx, data=ids, op0=nl.maximum, operand0=0.0)
    idrow = nl.ndarray((1, kpad), dtype=nl.float32, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=idrow,
        src=idx_hbm.ap(pattern=[[kpad, 1], [1, kpad]], offset=tok0 * kpad,
                       scalar_offset=i, indirect_dim=0),
    )
    brow = nl.ndarray((1, kpad), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=brow, data=idrow, op0=nl.less, operand0=0.0,
                       op1=nl.multiply, operand1=NEG_BOUND)
    bias_b = nl.broadcast_to(brow, (heads, kpad))
    # the snake, per score block of `bw` columns: block offset j at [j % 16, j // 16]
    # of each quadrant
    ix32 = nl.ndarray((PT, nblk, ncol), dtype=nl.int32, buffer=nl.sbuf)
    nisa.memset(ix32, 0)
    for qd in range(4):
        nisa.dma_copy(
            dst=ix32[32 * qd : 32 * qd + 16, 0:nblk, 0:ncol],
            src=idx_hbm.ap(pattern=[[1, 16], [bw, nblk], [16, ncol]], offset=tok0 * kpad,
                           scalar_offset=i, indirect_dim=0),
        )
    nisa.tensor_scalar(dst=ix32, data=ix32, op0=nl.maximum, operand0=0)
    ixs = []
    for nb in range(nblk):
        ix = nl.ndarray((PT, ncol), dtype=nl.uint16, buffer=nl.sbuf)
        nisa.tensor_copy(dst=ix, src=ix32[0:PT, nb, 0:ncol])
        ixs.append(ix)

    qrow = nl.ndarray((hp, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.dma_copy(
        dst=qrow[0:heads, :],
        src=q_hbm.ap(pattern=[[d, heads], [1, d]], offset=tok0 * hw, scalar_offset=i, indirect_dim=0),
    )
    qt = nl.ndarray((PT, dchunks, hp), dtype=nl.bfloat16, buffer=nl.sbuf)
    for c in range(dchunks):
        qps = nl.ndarray((PT, hp), dtype=nl.bfloat16, buffer=nl.psum)
        nisa.nc_transpose(dst=qps[0:PT, 0:heads], data=qrow[0:heads, c * PT : (c + 1) * PT])
        nisa.tensor_copy(dst=qt[0:PT, c, 0:heads], src=qps[0:PT, 0:heads])

    gn = nl.ndarray((PT, ktiles, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    for kb in range(ktiles):
        nisa.dma_copy(
            dst=gn[0:PT, kb, 0:d],
            src=kvtab_hbm.ap(pattern=[[d, PT], [1, d]], offset=0,
                             vector_offset=gidx[0:PT, kb : kb + 1], indirect_dim=0),
        )

    sc = nl.ndarray((heads, kpad), dtype=nl.float32, buffer=nl.sbuf)
    for nb in range(nblk):
        acc = accs[nb]
        for c in range(dchunks):
            nisa.nc_matmul(
                dst=acc, stationary=qt[0:PT, c, 0:heads],
                moving=kTs[c].indirect(ixs[nb], num_elem=bw), accumulate=(c > 0),
            )
        nisa.scalar_tensor_tensor(
            dst=sc[0:heads, nb * bw : (nb + 1) * bw], data=acc, op0=nl.multiply, operand0=scale,
            op1=nl.add, operand1=bias_b[0:heads, nb * bw : (nb + 1) * bw],
        )

    neg_max = nl.negative(nl.max(sc[0:heads, 0:kpad], axis=1, keepdims=True))
    p32 = nl.ndarray((heads, kpad), dtype=nl.float32, buffer=nl.sbuf)
    den = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.activation(dst=p32, op=nl.exp, data=sc[0:heads, 0:kpad], bias=neg_max, scale=1.0,
                    reduce_op=nl.add, reduce_res=den)
    sk = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.activation(dst=sk, op=nl.exp, data=sink_t, bias=neg_max)
    rcp = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
    nisa.reciprocal(dst=rcp, data=nl.add(den, sk))
    p16 = nl.copy(p32, dtype=nl.bfloat16)

    pt = nl.ndarray((PT, ktiles, hp), dtype=nl.bfloat16, buffer=nl.sbuf)
    for kb in range(ktiles):
        ptps = nl.ndarray((PT, hp), dtype=nl.bfloat16, buffer=nl.psum)
        nisa.nc_transpose(dst=ptps[0:PT, 0:heads], data=p16[0:heads, kb * PT : (kb + 1) * PT])
        nisa.tensor_copy(dst=pt[0:PT, kb, 0:heads], src=ptps[0:PT, 0:heads])
    acc_o = nl.ndarray((heads, d), dtype=nl.float32, buffer=nl.psum)
    for kb in range(ktiles):
        nisa.nc_matmul(dst=acc_o, stationary=pt[0:PT, kb, 0:heads], moving=gn[0:PT, kb, 0:d],
                       accumulate=(kb > 0))
    o16 = nl.ndarray((hp, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=o16[0:heads, :], data=acc_o, op0=nl.multiply, operand0=rcp)
    nisa.dma_copy(
        dst=o_hbm.ap(pattern=[[d, heads], [1, d]], offset=tok0 * hw, scalar_offset=i, indirect_dim=0),
        src=o16[0:heads, :],
    )


def attn_tokens(i, toks, q_hbm, kvtab_hbm, kTs, accs, idx_hbm, o_hbm, sink_t, heads, d, kpad, scale,
                idxp_hbm=None):
    """`attn_token_body_ti` (`kTs` given) or `attn_token_body` (`kTs` None: the keys
    transposed from the gathered rows on the PE) for `len(toks)` tokens per loop step,
    emitted stage by stage
    (indices and gathers of every token first, then the matmuls, softmaxes, PV) so the
    tokens' DMA and compute chains overlap. Token `u` is row `toks[u] + i * U` of the
    `[Tp, ...]` tables: `q_hbm` / `idx_hbm` / `o_hbm` come reshaped to `U` rows per
    step (`[Tp / U, U * width]`), so the loop register `i` steps `U` rows. `accs` are
    the resident path's score accumulator sets (`ti_score_psum`), token `u` uses set
    `u % len(accs)`. Same arithmetic per token as the single-token bodies.

    With `idxp_hbm` (the permuted index table of `attn_index_table`, reshaped like
    `idx_hbm`) a token's values are gathered by ONE batched indirect DMA (2-D
    `vector_offset`: the index is read column-major and the rows land row-major, so
    the permutation puts key `m * 128 + p` at `gn[p, m]`, the same layout)."""
    U = len(toks)
    ti = kTs is not None
    dchunks = d // PT
    ktiles = kpad // PT
    kt = _ktile(kpad)
    bw = _ti_block(kpad)
    nblk = kpad // bw
    ncol = bw // 16
    hp = _align16(heads)
    hw = heads * d

    # indices (gather column, bias row, snake) and the value gathers
    gns, biases, ixss, qrows = [], [], [], []
    for u in range(U):
        t0 = toks[u]
        ids = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(
            dst=ids,
            src=idx_hbm.ap(pattern=[[1, PT], [PT, ktiles]], offset=t0 * kpad,
                           scalar_offset=i, indirect_dim=0),
        )
        gidx = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=gidx, data=ids, op0=nl.maximum, operand0=0.0)
        gn = nl.ndarray((PT, ktiles, d), dtype=nl.bfloat16, buffer=nl.sbuf)
        if idxp_hbm is not None:
            pids = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
            nisa.dma_copy(
                dst=pids,
                src=idxp_hbm.ap(pattern=[[1, PT], [PT, ktiles]], offset=t0 * kpad,
                                scalar_offset=i, indirect_dim=0),
            )
            pidx = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
            nisa.tensor_scalar(dst=pidx, data=pids, op0=nl.maximum, operand0=0.0)
            nisa.dma_copy(
                dst=gn,
                src=kvtab_hbm.ap(pattern=[[d, PT * ktiles], [1, d]], offset=0,
                                 vector_offset=pidx, indirect_dim=0),
            )
        else:
            for kb in range(ktiles):
                nisa.dma_copy(
                    dst=gn[0:PT, kb, 0:d],
                    src=kvtab_hbm.ap(pattern=[[d, PT], [1, d]], offset=0,
                                     vector_offset=gidx[0:PT, kb : kb + 1], indirect_dim=0),
                )
        gns.append(gn)
    for u in range(U):
        t0 = toks[u]
        if ti:
            ix32 = nl.ndarray((PT, nblk, ncol), dtype=nl.int32, buffer=nl.sbuf)
            nisa.memset(ix32, 0)
            for qd in range(4):
                nisa.dma_copy(
                    dst=ix32[32 * qd : 32 * qd + 16, 0:nblk, 0:ncol],
                    src=idx_hbm.ap(pattern=[[1, 16], [bw, nblk], [16, ncol]], offset=t0 * kpad,
                                   scalar_offset=i, indirect_dim=0),
                )
            nisa.tensor_scalar(dst=ix32, data=ix32, op0=nl.maximum, operand0=0)
            ixs = []
            for nb in range(nblk):
                ix = nl.ndarray((PT, ncol), dtype=nl.uint16, buffer=nl.sbuf)
                nisa.tensor_copy(dst=ix, src=ix32[0:PT, nb, 0:ncol])
                ixs.append(ix)
            ixss.append(ixs)
        qrow = nl.ndarray((hp, d), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.dma_copy(
            dst=qrow[0:heads, :],
            src=q_hbm.ap(pattern=[[d, heads], [1, d]], offset=t0 * hw, scalar_offset=i, indirect_dim=0),
        )
        qrows.append(qrow)
        idrow = nl.ndarray((1, kpad), dtype=nl.float32, buffer=nl.sbuf)
        nisa.dma_copy(
            dst=idrow,
            src=idx_hbm.ap(pattern=[[kpad, 1], [1, kpad]], offset=t0 * kpad,
                           scalar_offset=i, indirect_dim=0),
        )
        brow = nl.ndarray((1, kpad), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=brow, data=idrow, op0=nl.less, operand0=0.0,
                           op1=nl.multiply, operand1=NEG_BOUND)
        biases.append(nl.broadcast_to(brow, (heads, kpad)))

    # q transposes and scores
    scs = []
    for u in range(U):
        qt = nl.ndarray((PT, dchunks, hp), dtype=nl.bfloat16, buffer=nl.sbuf)
        for c in range(dchunks):
            qps = nl.ndarray((PT, hp), dtype=nl.bfloat16, buffer=nl.psum)
            nisa.nc_transpose(dst=qps[0:PT, 0:heads], data=qrows[u][0:heads, c * PT : (c + 1) * PT])
            nisa.tensor_copy(dst=qt[0:PT, c, 0:heads], src=qps[0:PT, 0:heads])
        sc = nl.ndarray((heads, kpad), dtype=nl.float32, buffer=nl.sbuf)
        if ti:
            for nb in range(nblk):
                acc = accs[u % len(accs)][nb]
                for c in range(dchunks):
                    nisa.nc_matmul(
                        dst=acc, stationary=qt[0:PT, c, 0:heads],
                        moving=kTs[c].indirect(ixss[u][nb], num_elem=bw), accumulate=(c > 0),
                    )
                nisa.scalar_tensor_tensor(
                    dst=sc[0:heads, nb * bw : (nb + 1) * bw], data=acc, op0=nl.multiply,
                    operand0=scale, op1=nl.add, operand1=biases[u][0:heads, nb * bw : (nb + 1) * bw],
                )
        else:
            gt = nl.ndarray((PT, dchunks, kpad), dtype=nl.bfloat16, buffer=nl.sbuf)
            for kb in range(ktiles):
                tps = nl.ndarray((PT, dchunks, PT), dtype=nl.bfloat16, buffer=nl.psum)
                for c in range(dchunks):
                    nisa.nc_transpose(dst=tps[0:PT, c, 0:PT], data=gns[u][0:PT, kb, c * PT : (c + 1) * PT])
                nisa.tensor_copy(dst=gt[0:PT, 0:dchunks, kb * PT : (kb + 1) * PT], src=tps)
            for nb in range(kpad // kt):
                acc = nl.ndarray((heads, kt), dtype=nl.float32, buffer=nl.psum)
                for c in range(dchunks):
                    nisa.nc_matmul(
                        dst=acc, stationary=qt[0:PT, c, 0:heads],
                        moving=gt[0:PT, c, nb * kt : (nb + 1) * kt], accumulate=(c > 0),
                    )
                nisa.scalar_tensor_tensor(
                    dst=sc[0:heads, nb * kt : (nb + 1) * kt], data=acc, op0=nl.multiply,
                    operand0=scale, op1=nl.add, operand1=biases[u][0:heads, nb * kt : (nb + 1) * kt],
                )
        scs.append(sc)

    # softmax, p transposes, PV, store
    for u in range(U):
        sc = scs[u]
        neg_max = nl.negative(nl.max(sc[0:heads, 0:kpad], axis=1, keepdims=True))
        p32 = nl.ndarray((heads, kpad), dtype=nl.float32, buffer=nl.sbuf)
        den = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=p32, op=nl.exp, data=sc[0:heads, 0:kpad], bias=neg_max, scale=1.0,
                        reduce_op=nl.add, reduce_res=den)
        sk = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=sk, op=nl.exp, data=sink_t, bias=neg_max)
        rcp = nl.ndarray((heads, 1), dtype=nl.float32, buffer=nl.sbuf)
        nisa.reciprocal(dst=rcp, data=nl.add(den, sk))
        p16 = nl.copy(p32, dtype=nl.bfloat16)

        pt = nl.ndarray((PT, ktiles, hp), dtype=nl.bfloat16, buffer=nl.sbuf)
        for kb in range(ktiles):
            ptps = nl.ndarray((PT, hp), dtype=nl.bfloat16, buffer=nl.psum)
            nisa.nc_transpose(dst=ptps[0:PT, 0:heads], data=p16[0:heads, kb * PT : (kb + 1) * PT])
            nisa.tensor_copy(dst=pt[0:PT, kb, 0:heads], src=ptps[0:PT, 0:heads])
        acc_o = nl.ndarray((heads, d), dtype=nl.float32, buffer=nl.psum)
        for kb in range(ktiles):
            nisa.nc_matmul(dst=acc_o, stationary=pt[0:PT, kb, 0:heads], moving=gns[u][0:PT, kb, 0:d],
                           accumulate=(kb > 0))
        o16 = nl.ndarray((hp, d), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=o16[0:heads, :], data=acc_o, op0=nl.multiply, operand0=rcp)
        nisa.dma_copy(
            dst=o_hbm.ap(pattern=[[d, heads], [1, d]], offset=toks[u] * hw, scalar_offset=i,
                         indirect_dim=0),
            src=o16[0:heads, :],
        )


#: Of a token's `kpad // 128` PSUM -> SBUF copies of its transposed keys, the tiles
#: copied on the scalar engine (the rest on the vector engine).
GT_COPY_ACT = (1, 3)
#: With the pair layout, the transposed keys stay packed (`key_tile_packed`): a
#: contiguous PSUM copy, and the score matmuls read each chunk with stride 2.
GT_PACKED = True


#: `attn_scores`: token u's key transposes are scheduled after token u - LAG's score
#: matmuls (a schedule-only dependency; 0 = none). Without it the compiler's list
#: schedule of the step varies between builds: some builds issue all of a step's key
#: transposes first and the score matmuls in one block after them (attention 3.57 ->
#: 4.2 ms at in8192_bs1).
ATTN_KT_LAG = 2
#: The pipelined loop schedules each step's DVE / ACT work (q / key copies, bias) after
#: the previous step's p-stationary copy (schedule-only): else a next-step key copy,
#: waiting on its gather, can sit ahead of it in the in-order DVE queue and stall the
#: step's PV (~8 us a step in some builds).
ATTN_STEP_ORDER = True
#: The step buffers carry the bf16 output tile the o store reads (allocated with them,
#: outside the loop): a loop-local one shared its SBUF address with the next step's
#: softmax temporaries, which then waited (WAR) for the o store DMA, queued on GpSimd
#: behind the next step's gathers (~12 us stalls).
ATTN_O16_BUF = True

#: Rows (tokens x heads) per softmax / PV group of `attn_step`.
ATTN_GROUP_ROWS = 128
#: `attn_softmax`: the row max negated by the reduce itself and the exponentials written
#: as bf16 by the exp activation (no fp32 copy + cast on the softmax -> PV path).
ATTN_SOFTMAX_FUSED = True
#: `attn_compute` fills a group's per-token masked q / p stationaries with ONE strided
#: copy each (token u's columns on its diagonal block) instead of one copy per token.
ATTN_DIAG_COPY = True


def _attn_groups(U, heads):
    """`(Ug, Mg)`: tokens and rows per `attn_step` group."""
    ug = max(1, min(U, ATTN_GROUP_ROWS // heads))
    while U % ug:
        ug -= 1
    return ug, ug * heads


def attn_step_masks(U, heads, d, kpad):
    """`attn_step`'s per-token masked stationaries, zeroed once outside the loop (the
    step writes only each token's own columns): `(qtm, ptm, sel)`; `qtm[:, u, c, :]` /
    `ptm[:, u, kb, :]` hold token `u`'s q / p columns (at its rows of its group) and
    zeros elsewhere; `sel[u, g, :]` is the 0/1 token-to-row selection of group `g`."""
    Ug, Mg = _attn_groups(U, heads)
    G = U // Ug
    qtm = nl.ndarray((PT, U, d // PT, Mg), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.memset(qtm, 0.0)
    ptm = nl.ndarray((PT, U, kpad // PT, Mg), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.memset(ptm, 0.0)
    # sel[u, g, c] = 1 if u == g * Ug + c // heads, i.e. heads*u - heads*Ug*g - c in (-heads, 0]
    rel = nl.ndarray((U, G, Mg), dtype=nl.int32, buffer=nl.sbuf)
    nisa.iota(dst=rel, pattern=[[-heads * Ug, G], [-1, Mg]], offset=0, channel_multiplier=heads)
    relf = nl.ndarray((U, G, Mg), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_copy(dst=relf, src=rel)
    le = nl.ndarray((U, G, Mg), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=le, data=relf, op0=nl.less_equal, operand0=0.0)
    gt_ = nl.ndarray((U, G, Mg), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_scalar(dst=gt_, data=relf, op0=nl.greater, operand0=float(-heads))
    sel = nl.ndarray((U, G, Mg), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.tensor_tensor(dst=sel, data1=le, data2=gt_, op=nl.multiply)
    return qtm, ptm, sel


#: `attn_fetch` loads its U tokens' gather indices with one DMA (else one per token).
ATTN_PIDS_MERGED = True


def _dyn_ap(t, pattern, offset, i):
    """`t.ap(pattern, offset)`, stepped by the loop register `i` (rows of `t`) unless
    `i` is None (a static access)."""
    if i is None:
        return t.ap(pattern=pattern, offset=offset)
    return t.ap(pattern=pattern, offset=offset, scalar_offset=i, indirect_dim=0)


def attn_step_bufs(U, heads, d, kpad):
    """The SBUF buffers one `attn_step` fetches into (`attn_fetch`) and computes from
    (`attn_compute`): the U tokens' gathered values, their q rows and index rows."""
    ktiles = kpad // PT
    b = dict(
        gns=[nl.ndarray((PT, ktiles, d), dtype=nl.bfloat16, buffer=nl.sbuf) for _ in range(U)],
        qrow=nl.ndarray((U * heads, d), dtype=nl.bfloat16, buffer=nl.sbuf),
        idrow=nl.ndarray((U, kpad), dtype=nl.float32, buffer=nl.sbuf),
    )
    if ATTN_O16_BUF:
        Ug, Mg = _attn_groups(U, heads)
        b["o16"] = [nl.ndarray((Mg, d), dtype=nl.bfloat16, buffer=nl.sbuf) for _ in range(U // Ug)]
    return b


def attn_fetch(i, tok0, U, q_hbm, kvtab_hbm, idx_hbm, heads, d, kpad, bufs, idxp_hbm=None):
    """`attn_step`'s loads for the `U` tokens `tok0 + R * i + u` (`R` = the rows per step
    of the reshaped `q_hbm` / `idx_hbm` / `idxp_hbm` views; `i` None = static tokens
    `tok0 + u`): the value gathers, the q rows and the index rows, into `bufs`."""
    M = U * heads
    ktiles = kpad // PT
    hw = heads * d
    gns = bufs["gns"]
    if idxp_hbm is not None and ATTN_PIDS_MERGED:
        # all U tokens' gather indices in one DMA: pall[a, u, q] = idxp[tok0 + u][q * 128 + a]
        pall = nl.ndarray((PT, U, ktiles), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=pall, src=_dyn_ap(idxp_hbm, [[ktiles, PT], [kpad, U], [1, ktiles]], tok0 * kpad, i))
    for u in range(U):
        t0 = tok0 + u
        gn = gns[u]
        if idxp_hbm is not None:
            # `attn_index_table`'s transposed rows: pids[a, q] = idxp[q * 128 + a]; empty
            # slots already point at zero rows (`zrow0`)
            if ATTN_PIDS_MERGED:
                pids = pall[0:PT, u, 0:ktiles]
            else:
                pids = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
                nisa.dma_copy(dst=pids, src=_dyn_ap(idxp_hbm, [[ktiles, PT], [1, ktiles]], t0 * kpad, i))
            nisa.dma_copy(
                dst=gn,
                src=kvtab_hbm.ap(pattern=[[d, PT * ktiles], [1, d]], offset=0,
                                 vector_offset=pids, indirect_dim=0),
            )
        else:
            ids = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
            nisa.dma_copy(dst=ids, src=_dyn_ap(idx_hbm, [[1, PT], [PT, ktiles]], t0 * kpad, i))
            gidx = nl.ndarray((PT, ktiles), dtype=nl.int32, buffer=nl.sbuf)
            nisa.tensor_scalar(dst=gidx, data=ids, op0=nl.maximum, operand0=0.0)
            for kb in range(ktiles):
                nisa.dma_copy(
                    dst=gn[0:PT, kb, 0:d],
                    src=kvtab_hbm.ap(pattern=[[d, PT], [1, d]], offset=0,
                                     vector_offset=gidx[0:PT, kb : kb + 1], indirect_dim=0),
                )
    # the step's q rows (one DMA)
    nisa.dma_copy(dst=bufs["qrow"], src=_dyn_ap(q_hbm, [[d, M], [1, d]], tok0 * hw, i))
    # the step's U index rows in one DMA
    nisa.dma_copy(dst=bufs["idrow"], src=_dyn_ap(idx_hbm, [[kpad, U], [1, kpad]], tok0 * kpad, i))


def attn_step(i, tok0, U, q_hbm, kvtab_hbm, idx_hbm, o_hbm, sink_u, masks, heads, d, kpad, scale,
              idxp_hbm=None):
    """`attn_token_body` for the `U` tokens `tok0 + U * i + u` of one loop step:
    `attn_fetch` then `attn_compute` (local buffers)."""
    bufs = attn_step_bufs(U, heads, d, kpad)
    attn_fetch(i, tok0, U, q_hbm, kvtab_hbm, idx_hbm, heads, d, kpad, bufs, idxp_hbm=idxp_hbm)
    attn_compute(i, tok0, U, o_hbm, bufs, sink_u, masks, heads, d, kpad, scale)


def _sched_after(ins, after):
    """Schedule-only dependency of `ins` on `after` (no hardware sync), if both exist."""
    if after is not None and ins is not None:
        ins.depends_on(after, kind=nisa.dependency.schedule)


def attn_compute(i, tok0, U, o_hbm, bufs, sink_u, masks, heads, d, kpad, scale, after=None):
    """The tokens of one `attn_fetch`ed step (`bufs`), stored to `o_hbm` (stepped like
    the fetch's views by `i`).

    The tokens are processed in groups of `Ug` (`_attn_groups`) with the group's
    tokens stacked on partitions: token `u`, head `h` is row `(u % Ug) * heads + h` of
    the group's score, softmax and output tiles, so the p transposes, the softmax,
    the scaling and the o store run once per group.

    The score and PV matmuls stay per token (each token has its own keys / values):
    token `u`'s use a stationary holding only its own columns (zeros elsewhere,
    `masks`), all accumulating into the group's PSUM tile. A row then receives its own
    token's partial products in the single-token order plus exact zeros from the other
    tokens' matmuls, so every value is the single-token body's.
    `sink_u` is a `(>= Mg, 1)` fp32 sink column (the heads' sinks repeated per token).

    The step runs as four phases (`attn_scores`, `attn_softmax`, `attn_pv`,
    `attn_store`); the 3-buffer pipelined loop interleaves consecutive steps' phases."""
    sts = attn_scores(U, bufs, masks, heads, d, kpad, after=after)
    sm = attn_softmax(U, sts, sink_u, heads, kpad, scale, bufs)
    pcs = []
    for g in range(len(sts)):
        acc_o = attn_pv(U, bufs, masks, heads, d, kpad, g, sm[g][0], pcs=pcs)
        attn_store(i, tok0, U, o_hbm, acc_o, sm[g][1], heads, d, g,
                   o16=bufs["o16"][g] if "o16" in bufs else None)
    # the last p-stationary copy: the next step's DVE / ACT work is scheduled after it
    # (`ATTN_STEP_ORDER`)
    return pcs[-1] if (pcs and ATTN_STEP_ORDER) else None


def attn_scores(U, bufs, masks, heads, d, kpad, after=None):
    """`attn_compute`'s q stationaries, empty-slot bias, key transposes and score
    matmuls: per group `(accs, bias)` (the score PSUM tiles and the fp32 bias).
    `after`: an instruction every DVE / ACT op here is scheduled after (schedule-only)."""
    M = U * heads
    Ug, Mg = _attn_groups(U, heads)
    G = U // Ug
    qtm, ptm, sel = masks
    dchunks = d // PT
    ktiles = kpad // PT
    kt = _ti_block(kpad)
    nkb = kpad // kt
    gns = bufs["gns"]
    qrow = bufs["qrow"]
    idrow = bufs["idrow"]

    # the q rows transposed; each token's columns into its stationary
    qps = nl.ndarray((PT, dchunks, M), dtype=nl.bfloat16, buffer=nl.psum)
    for c in range(dchunks):
        nisa.nc_transpose(dst=qps[0:PT, c, 0:M], data=qrow[0:M, c * PT : (c + 1) * PT])
    if ATTN_DIAG_COPY:
        # one copy per group: token u's heads columns land on its block of the diagonal
        for g in range(G):
            u0 = g * Ug
            qc = nisa.tensor_copy(
                dst=qtm.ap(pattern=[[U * dchunks * Mg, PT], [dchunks * Mg + heads, Ug], [Mg, dchunks],
                                    [1, heads]], offset=u0 * dchunks * Mg),
                src=qps.ap(pattern=[[dchunks * M, PT], [heads, Ug], [M, dchunks], [1, heads]],
                           offset=u0 * heads))
            _sched_after(qc, after)
    else:
        for u in range(U):
            c0 = (u % Ug) * heads
            nisa.tensor_copy(dst=qtm[0:PT, u, 0:dchunks, c0 : c0 + heads],
                             src=qps[0:PT, 0:dchunks, u * heads : (u + 1) * heads])

    # the index rows' empty-slot masks (0/1, exact in bf16) repeated over each token's
    # heads by the 0/1 selection matmul `sel`; bias = mask * NEG_BOUND in fp32, the
    # single-token body's value
    emask = nl.ndarray((U, kpad), dtype=nl.bfloat16, buffer=nl.sbuf)
    _sched_after(nisa.tensor_scalar(dst=emask, data=idrow, op0=nl.less, operand0=0.0), after)

    out = []
    for g in range(G):
        us = range(g * Ug, (g + 1) * Ug)
        bias = nl.ndarray((Mg, kpad), dtype=nl.float32, buffer=nl.sbuf)
        for nb in range(nkb):
            bps = nl.ndarray((Mg, kt), dtype=nl.float32, buffer=nl.psum)
            nisa.nc_matmul(dst=bps, stationary=sel[0:U, g, 0:Mg], moving=emask[0:U, nb * kt : (nb + 1) * kt])
            _sched_after(nisa.tensor_scalar(dst=bias[0:Mg, nb * kt : (nb + 1) * kt], data=bps,
                                            op0=nl.multiply, operand0=NEG_BOUND), after)

        # key transposes and scores, token by token into the group's score tiles
        accs = [nl.ndarray((Mg, kt), dtype=nl.float32, buffer=nl.psum) for _ in range(nkb)]
        last_mm = {}
        for u in us:
            packed = kv_pair_layout(d) and GT_PACKED
            if packed:
                gtp = nl.ndarray((PT, dchunks // 2, kpad, 2), dtype=nl.bfloat16, buffer=nl.sbuf)
            else:
                gt = nl.ndarray((PT, dchunks, kpad), dtype=nl.bfloat16, buffer=nl.sbuf)
            for kb in range(ktiles):
                eng = nisa.scalar_engine if kb in GT_COPY_ACT else nisa.vector_engine
                if packed:
                    t0_ins, cp_ins = key_tile_packed(gns[u], kb, gtp, d, eng)
                    _sched_after(cp_ins, after)
                    if (ATTN_KT_LAG and kb == 0 and u - ATTN_KT_LAG in last_mm
                            and t0_ins is not None and last_mm[u - ATTN_KT_LAG] is not None):
                        # schedule-only: token u's key transposes after token u - LAG's
                        # scores (the transposes do not run ahead of the score matmuls,
                        # filling PSUM while the DVE / ACT copies drain it)
                        t0_ins.depends_on(last_mm[u - ATTN_KT_LAG], kind=nisa.dependency.schedule)
                else:
                    key_tile_t(gns[u], kb, gt, d, eng)
            # chunk-outer: consecutive matmuls share the stationary; each score tile still
            # accumulates its chunks in order
            for c in range(dchunks):
                for nb in range(nkb):
                    mv = (gtp[0:PT, c // 2, nb * kt : (nb + 1) * kt, c % 2] if packed
                          else gt[0:PT, c, nb * kt : (nb + 1) * kt])
                    last_mm[u] = nisa.nc_matmul(
                        dst=accs[nb], stationary=qtm[0:PT, u, c, 0:Mg],
                        moving=mv, accumulate=(u > us[0] or c > 0),
                    )
        out.append((accs, bias))
    return out


def attn_softmax(U, sts, sink_u, heads, kpad, scale, bufs):
    """`attn_compute`'s scaled, biased scores and their softmax, per group `(p16, rcp)`
    (the bf16 probabilities and the fp32 1 / (sum + sink)); into `bufs["p16"]` /
    `bufs["rcp"]` when the step buffers carry them (`attn_bufs3`)."""
    Ug, Mg = _attn_groups(U, heads)
    kt = _ti_block(kpad)
    nkb = kpad // kt
    out = []
    for g, (accs, bias) in enumerate(sts):
        sc = nl.ndarray((Mg, kpad), dtype=nl.float32, buffer=nl.sbuf)
        for nb in range(nkb):
            nisa.scalar_tensor_tensor(
                dst=sc[0:Mg, nb * kt : (nb + 1) * kt], data=accs[nb], op0=nl.multiply,
                operand0=scale, op1=nl.add, operand1=bias[0:Mg, nb * kt : (nb + 1) * kt],
            )

        # softmax of the group's rows
        if ATTN_SOFTMAX_FUSED:
            neg_max = nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_reduce(dst=neg_max, op=nl.maximum, data=sc[0:Mg, 0:kpad], axis=1, negate=True,
                               keepdims=True)
        else:
            neg_max = nl.negative(nl.max(sc[0:Mg, 0:kpad], axis=1, keepdims=True))
        den = nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf)
        if ATTN_SOFTMAX_FUSED and "rcp" not in bufs:
            # the exponentials written as bf16 by the activation itself (its fp32 sum is
            # the reduce, as before)
            p16 = nl.ndarray((Mg, kpad), dtype=nl.bfloat16, buffer=nl.sbuf)
            nisa.activation(dst=p16, op=nl.exp, data=sc[0:Mg, 0:kpad], bias=neg_max, scale=1.0,
                            reduce_op=nl.add, reduce_res=den)
            sk = nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf)
            nisa.activation(dst=sk, op=nl.exp, data=sink_u[0:Mg, :], bias=neg_max)
            rcp = nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf)
            nisa.reciprocal(dst=rcp, data=nl.add(den, sk))
            out.append((p16, rcp))
            continue
        p32 = nl.ndarray((Mg, kpad), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=p32, op=nl.exp, data=sc[0:Mg, 0:kpad], bias=neg_max, scale=1.0,
                        reduce_op=nl.add, reduce_res=den)
        sk = nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=sk, op=nl.exp, data=sink_u[0:Mg, :], bias=neg_max)
        if "rcp" in bufs:
            rcp = bufs["rcp"][g]
            p16 = bufs["p16"][g]
            nisa.reciprocal(dst=rcp[0:Mg, :], data=nl.add(den, sk))
            nisa.tensor_copy(dst=p16[0:Mg, :], src=p32, engine=nisa.vector_engine)
        else:
            rcp = nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf)
            nisa.reciprocal(dst=rcp, data=nl.add(den, sk))
            p16 = nl.copy(p32, dtype=nl.bfloat16)
        out.append((p16, rcp))
    return out


def attn_pv(U, bufs, masks, heads, d, kpad, g, p16, pcs=None):
    """`attn_compute`'s p transposes into the masked stationaries and the PV matmuls of
    group `g`: the `(Mg, d)` fp32 PSUM output."""
    Ug, Mg = _attn_groups(U, heads)
    qtm, ptm, sel = masks
    ktiles = kpad // PT
    gns = bufs["gns"]
    us = range(g * Ug, (g + 1) * Ug)
    ptps = nl.ndarray((PT, ktiles, Mg), dtype=nl.bfloat16, buffer=nl.psum)
    for kb in range(ktiles):
        nisa.nc_transpose(dst=ptps[0:PT, kb, 0:Mg], data=p16[0:Mg, kb * PT : (kb + 1) * PT])
    if ATTN_DIAG_COPY:
        pc = nisa.tensor_copy(
            dst=ptm.ap(pattern=[[U * ktiles * Mg, PT], [ktiles * Mg + heads, Ug], [Mg, ktiles],
                                [1, heads]], offset=us[0] * ktiles * Mg),
            src=ptps.ap(pattern=[[ktiles * Mg, PT], [heads, Ug], [Mg, ktiles], [1, heads]], offset=0))
        if pcs is not None:
            pcs.append(pc)
    else:
        for u in us:
            c0 = (u % Ug) * heads
            nisa.tensor_copy(dst=ptm[0:PT, u, 0:ktiles, c0 : c0 + heads],
                             src=ptps[0:PT, 0:ktiles, c0 : c0 + heads])

    # PV, token by token into the group's output tile; one scaling and one store
    acc_o = nl.ndarray((Mg, d), dtype=nl.float32, buffer=nl.psum)
    for u in us:
        for kb in range(ktiles):
            nisa.nc_matmul(dst=acc_o, stationary=ptm[0:PT, u, kb, 0:Mg], moving=gns[u][0:PT, kb, 0:d],
                           accumulate=(u > us[0] or kb > 0))
    return acc_o


def attn_store(i, tok0, U, o_hbm, acc_o, rcp, heads, d, g, o16=None):
    """`attn_compute`'s output scaling (`pv_out`) and store of group `g` (through the
    step buffer's `o16` when given)."""
    Ug, Mg = _attn_groups(U, heads)
    hw = heads * d
    if o16 is None:
        o16 = nl.ndarray((Mg, d), dtype=nl.bfloat16, buffer=nl.sbuf)
    pv_out(o16, acc_o, Mg, rcp[0:Mg, :], d)
    nisa.dma_copy(
        dst=o_hbm.ap(pattern=[[d, Mg], [1, d]], offset=(tok0 + g * Ug) * hw, scalar_offset=i,
                     indirect_dim=0),
        src=o16,
    )


#: Pipelined attention loop with THREE step buffers (`attn_bufs3`): step s + 1's key
#: transposes and score matmuls are issued before step s's p transposes and PV, so the
#: tensor engine works on them while step s's softmax runs on DVE / ACT (instead of
#: idling); step s + 3 is fetched into step s's buffer once its PV has read it.
#: Every value is computed by the same instructions as `attn_compute`'s.
#: OFF: bit-exact but slower at in8192_bs1 (attention 3.60 -> 4.7 ms with 3 buffers,
#: ~4.5 with 4): the tensor engine still stalls ~8 us a step on the gathers (iter-5 notes).
ATTN_PIPE3 = False
#: Step buffers of that loop (step s + NBUF is fetched into step s's buffer after its
#: PV: NBUF - 2 steps of lead for the gathers) and steps per iteration (a multiple of
#: NBUF, so a step's buffer is the same in every iteration).
ATTN_PIPE3_NBUF = 4
ATTN_PIPE3_STEPS = 4


def attn_bufs3(U, heads, d, kpad):
    """`attn_step_bufs` plus the step's softmax results (written by `attn_softmax`,
    read by the next phases one pipeline stage later)."""
    b = attn_step_bufs(U, heads, d, kpad)
    Ug, Mg = _attn_groups(U, heads)
    G = U // Ug
    b["p16"] = [nl.ndarray((Mg, kpad), dtype=nl.bfloat16, buffer=nl.sbuf) for _ in range(G)]
    b["rcp"] = [nl.ndarray((Mg, 1), dtype=nl.float32, buffer=nl.sbuf) for _ in range(G)]
    return b


# --------------------------------------------------------------------------- MoE routing


def route_topk(scores_hbm, bias_hbm, lo_hbm, tiles, n_experts, topk, n_local, route_scale,
               wexp_hbm):
    """The router selection: `sqrtsoftplus` of the fp32 logits in `scores_hbm[T, n_experts]`,
    top-`topk` of `score + bias`, raw-score weights normalized to sum 1 and scaled, and
    per-local-expert dense weights `wexp_hbm[T, n_local]` (fp32): the routing weight of
    expert `lo + e` for the row, or 0 when the row did not pick it.
    """
    for r0, nr in tiles:
        lg = nl.ndarray((PT, n_experts), dtype=nl.float32, buffer=nl.sbuf)
        nisa.dma_copy(dst=lg[0:nr, :], src=scores_hbm[r0 : r0 + nr, 0:n_experts])
        sp = nl.ndarray((PT, n_experts), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=sp[0:nr, :], op=nl.softplus, data=lg[0:nr, :])
        scores = nl.ndarray((PT, n_experts), dtype=nl.float32, buffer=nl.sbuf)
        nisa.activation(dst=scores[0:nr, :], op=nl.sqrt, data=sp[0:nr, :])
        bb = bcast_dma(bias_hbm, 0, n_experts, nr)
        sel = nl.ndarray((PT, n_experts), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=sel[0:nr, :], data1=scores[0:nr, :], data2=bb, op=nl.add)
        best = nl.ndarray((PT, 8), dtype=nl.float32, buffer=nl.sbuf)
        nisa.max8(dst=best[0:nr, :], src=sel[0:nr, :])
        idx8 = nl.ndarray((PT, 8), dtype=nl.uint32, buffer=nl.sbuf)
        nisa.nc_find_index8(dst=idx8[0:nr, :], data=sel[0:nr, :], vals=best[0:nr, :])
        picked = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.nc_n_gather(dst=picked[0:nr, :], data=scores[0:nr, :], indices=idx8[0:nr, 0:topk])
        tot = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_reduce(dst=tot[0:nr, :], op=nl.add, data=picked[0:nr, :], axis=(1,), keepdims=True)
        inv = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        inv[0:nr, :] = nl.multiply(nl.reciprocal(nl.add(tot[0:nr, :], 1e-20)), route_scale)
        wts = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=wts[0:nr, :], data=picked[0:nr, :], op0=nl.multiply, operand0=inv[0:nr, 0:1])
        idf = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=idf[0:nr, :], src=idx8[0:nr, 0:topk])
        lo = bcast_dma(lo_hbm, 0, 1, nr)  # fp32 [1, 1] from the host
        wexp = nl.ndarray((PT, n_local), dtype=nl.float32, buffer=nl.sbuf)
        for e in range(n_local):
            target = nl.add(lo, float(e))
            m = nl.ndarray((PT, topk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_scalar(dst=m[0:nr, :], data=idf[0:nr, :], op0=nl.equal, operand0=target[0:nr, 0:1])
            nisa.tensor_tensor(dst=m[0:nr, :], data1=m[0:nr, :], data2=wts[0:nr, :], op=nl.multiply)
            nisa.tensor_reduce(dst=wexp[0:nr, e : e + 1], op=nl.add, data=m[0:nr, :], axis=(1,), keepdims=True)
        nisa.dma_copy(dst=wexp_hbm[r0 : r0 + nr, 0:n_local], src=wexp[0:nr, :])


def _swiglu_chunk(inter):
    for cand in (1152, 768, 576, 512, 384, 256, 128, 64, 32):
        if inter % cand == 0:
            return cand
    return inter


def swiglu_rows(gate_hbm, up_hbm, w_hbm, wcol, dst_hbm, tiles, inter, limit, chunk=None):
    """`dst = bf16( silu(min(gate, limit)) * clamp(up, -limit, limit) * w )` for the row
    tiles; `w_hbm[T, n_local]` column `wcol` is the per-row routing weight (or None for
    the shared expert's unit weight). `kernels.swiglu`'s arithmetic.
    """
    chunk = chunk or _swiglu_chunk(inter)
    for r0, nr in tiles:
        if w_hbm is not None:
            w = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=w[0:nr, :], src=w_hbm[r0 : r0 + nr, wcol : wcol + 1])
        for j in range(inter // chunk):
            c0 = j * chunk
            g = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=g[0:nr, :], src=gate_hbm[r0 : r0 + nr, c0 : c0 + chunk])
            nisa.tensor_scalar(dst=g[0:nr, :], data=g[0:nr, :], op0=nl.minimum, operand0=limit)
            u = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=u[0:nr, :], src=up_hbm[r0 : r0 + nr, c0 : c0 + chunk])
            nisa.tensor_scalar(dst=u[0:nr, :], data=u[0:nr, :], op0=nl.maximum, operand0=-limit,
                               op1=nl.minimum, operand1=limit)
            sg = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.activation(dst=sg[0:nr, :], op=nl.silu, data=g[0:nr, :])
            # the last product writes bf16 directly (its fp32 result cast on output)
            y16 = nl.ndarray((PT, chunk), dtype=nl.bfloat16, buffer=nl.sbuf)
            if w_hbm is not None:
                y = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
                nisa.tensor_tensor(dst=y[0:nr, :], data1=sg[0:nr, :], data2=u[0:nr, :], op=nl.multiply)
                nisa.tensor_scalar(dst=y16[0:nr, :], data=y[0:nr, :], op0=nl.multiply, operand0=w[0:nr, 0:1])
            else:
                nisa.tensor_tensor(dst=y16[0:nr, :], data1=sg[0:nr, :], data2=u[0:nr, :], op=nl.multiply)
            nisa.dma_copy(dst=dst_hbm[r0 : r0 + nr, c0 : c0 + chunk], src=y16[0:nr, :])


def add_rows(acc_hbm, src_hbm, tiles, n, first, chunk=1024):
    """`acc[rows] (+)= src[rows]` in fp32 (`src` bf16 or fp32); `first` initializes."""
    chunk = min(chunk, n)
    for r0, nr in tiles:
        for c in range(n // chunk):
            lo, hi = c * chunk, (c + 1) * chunk
            s = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=s[0:nr, :], src=src_hbm[r0 : r0 + nr, lo:hi])
            if first:
                nisa.dma_copy(dst=acc_hbm[r0 : r0 + nr, lo:hi], src=s[0:nr, :])
            else:
                a = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
                nisa.dma_copy(dst=a[0:nr, :], src=acc_hbm[r0 : r0 + nr, lo:hi])
                nisa.tensor_tensor(dst=a[0:nr, :], data1=a[0:nr, :], data2=s[0:nr, :], op=nl.add)
                nisa.dma_copy(dst=acc_hbm[r0 : r0 + nr, lo:hi], src=a[0:nr, :])


def cast_rows(src_hbm, dst_hbm, tiles, n, dtype, chunk=1024):
    """`dst[rows] = dtype(src[rows])`."""
    chunk = min(chunk, n)
    for r0, nr in tiles:
        for c in range(n // chunk):
            lo, hi = c * chunk, (c + 1) * chunk
            s = nl.ndarray((PT, chunk), dtype=dtype, buffer=nl.sbuf)
            nisa.dma_copy(dst=s[0:nr, :], src=src_hbm[r0 : r0 + nr, lo:hi])
            nisa.dma_copy(dst=dst_hbm[r0 : r0 + nr, lo:hi], src=s[0:nr, :])


# --------------------------------------------------------------------------- engram


def engram_gather(ids_hbm, table_hbm, row_start_hbm, emb_hbm, tiles, ncol, hd, row_width):
    """`emb[t, j*hd:(j+1)*hd] = table[ids[t, j] - row_start]` where the row is this rank's,
    else 0 -- this rank's contribution to the n-gram rows (summed across ranks after)."""
    for r0, nr in tiles:
        ids = nl.ndarray((PT, ncol), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=ids[0:nr, :], src=ids_hbm[r0 : r0 + nr, 0:ncol])
        idf = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=idf[0:nr, :], src=ids[0:nr, :])
        rs = bcast_row(row_start_hbm[0:1, 0:1], 1, nr)
        loc = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=loc[0:nr, :], data=idf[0:nr, :], op0=nl.subtract, operand0=rs[0:nr, 0:1])
        # mask = (loc >= 0) * (loc < row_width); clamped = min(max(loc, 0), row_width - 1)
        m0 = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=m0[0:nr, :], data=loc[0:nr, :], op0=nl.greater_equal, operand0=0.0)
        m1 = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=m1[0:nr, :], data=loc[0:nr, :], op0=nl.less, operand0=float(row_width))
        mask = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=mask[0:nr, :], data1=m0[0:nr, :], data2=m1[0:nr, :], op=nl.multiply)
        cl = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=cl[0:nr, :], data=loc[0:nr, :], op0=nl.maximum, operand0=0.0,
                           op1=nl.minimum, operand1=float(row_width - 1))
        cli = nl.ndarray((PT, ncol), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=cli[0:nr, :], src=cl[0:nr, :])
        for j in range(ncol):
            g = nl.ndarray((PT, hd), dtype=nl.bfloat16, buffer=nl.sbuf)
            nisa.dma_copy(dst=g[0:nr, :], src=table_hbm.ap(pattern=[[hd, nr], [1, hd]],
                                                            vector_offset=cli[0:nr, j : j + 1], indirect_dim=0))
            gf = nl.ndarray((PT, hd), dtype=nl.float32, buffer=nl.sbuf)
            nisa.tensor_scalar(dst=gf[0:nr, :], data=g[0:nr, :], op0=nl.multiply, operand0=mask[0:nr, j : j + 1])
            g16 = nl.ndarray((PT, hd), dtype=nl.bfloat16, buffer=nl.sbuf)
            nisa.tensor_copy(dst=g16[0:nr, :], src=gf[0:nr, :])
            nisa.dma_copy(dst=emb_hbm[r0 : r0 + nr, j * hd : (j + 1) * hd], src=g16[0:nr, :])



def engram_gather_fp8(ids_hbm, table_hbm, row_start_hbm, emb_hbm, tiles, ncol, hd, row_width):
    """`engram_gather` over an fp8 table (`engram_hd`): each tile's `ncol` row gathers into one
    `[PT, ncol, hd + hd / 32]` uint8 tile, dequantized and masked together (`engram_dequant`)."""
    ec = table_hbm.shape[1]
    for r0, nr in tiles:
        ids = nl.ndarray((PT, ncol), dtype=nl.int32, buffer=nl.sbuf)
        nisa.dma_copy(dst=ids[0:nr, :], src=ids_hbm[r0 : r0 + nr, 0:ncol])
        idf = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=idf[0:nr, :], src=ids[0:nr, :])
        rs = bcast_row(row_start_hbm[0:1, 0:1], 1, nr)
        loc = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=loc[0:nr, :], data=idf[0:nr, :], op0=nl.subtract, operand0=rs[0:nr, 0:1])
        m0 = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=m0[0:nr, :], data=loc[0:nr, :], op0=nl.greater_equal, operand0=0.0)
        m1 = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=m1[0:nr, :], data=loc[0:nr, :], op0=nl.less, operand0=float(row_width))
        mask = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=mask[0:nr, :], data1=m0[0:nr, :], data2=m1[0:nr, :], op=nl.multiply)
        cl = nl.ndarray((PT, ncol), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_scalar(dst=cl[0:nr, :], data=loc[0:nr, :], op0=nl.maximum, operand0=0.0,
                           op1=nl.minimum, operand1=float(row_width - 1))
        cli = nl.ndarray((PT, ncol), dtype=nl.int32, buffer=nl.sbuf)
        nisa.tensor_copy(dst=cli[0:nr, :], src=cl[0:nr, :])
        g8 = nl.ndarray((PT, ncol, ec), dtype=nl.uint8, buffer=nl.sbuf)
        for j in range(ncol):
            nisa.dma_copy(dst=g8[0:nr, j, :], src=table_hbm.ap(pattern=[[ec, nr], [1, ec]],
                                                                vector_offset=cli[0:nr, j : j + 1], indirect_dim=0))
        e16 = engram_dequant(g8, nr, ncol, hd, mask)
        nisa.dma_copy(dst=emb_hbm[r0 : r0 + nr, 0 : ncol * hd], src=e16.reshape((PT, ncol * hd))[0:nr, :])


def engram_hd(etable):
    """The engram row width in values: a bf16 table `[rows, hd]`, or the fp8 one `[rows, hd + hd / 32]`
    uint8 (`weight_loader`: hd e4m3fn codes, then hd / 32 e8m0 scales)."""
    ec = etable.shape[1]
    if etable.dtype == nl.uint8:
        assert ec % 33 == 0, f"fp8 engram row of {ec} bytes"
        return ec // 33 * 32
    return ec


def engram_dequant(g8, nr, G, ehd, mask=None):
    """Gathered fp8 engram rows `g8` `[PT, G, ehd + ehd / 32]` uint8 -> `[PT, G, ehd]` bf16 (x `mask`
    `[PT, G]` fp32): code * 2^(e - 127), exact in bf16 (`weight_loader.dequant_engram_rows`)."""
    nb = ehd // 32
    # the scales' fp32 bit patterns e << 23 = 2^(e - 127): e * 2^23 is an exact integer in fp32
    sf = nl.ndarray((PT, G, nb), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_copy(dst=sf[0:nr], src=g8[0:nr, :, ehd : ehd + nb])
    nisa.tensor_scalar(dst=sf[0:nr], data=sf[0:nr], op0=nl.multiply, operand0=8388608.0)
    si = nl.ndarray((PT, G, nb), dtype=nl.int32, buffer=nl.sbuf)
    nisa.tensor_copy(dst=si[0:nr], src=sf[0:nr])
    sc = si.view(nl.float32)
    if mask is not None:
        scm = nl.ndarray((PT, G, nb), dtype=nl.float32, buffer=nl.sbuf)
        nisa.tensor_tensor(dst=scm[0:nr], data1=sc[0:nr],
                           data2=mask.ap(pattern=[[G, nr], [1, G], [0, nb]], offset=0), op=nl.multiply)
        sc = scm
    vals = nl.ndarray((PT, G, ehd), dtype=nl.float32, buffer=nl.sbuf)
    nisa.tensor_copy(dst=vals[0:nr], src=g8.view(nl.float8_e4m3fn)[0:nr, :, 0:ehd])
    e16 = nl.ndarray((PT, G, ehd), dtype=nl.bfloat16, buffer=nl.sbuf)
    nisa.tensor_tensor(dst=e16.reshape((PT, G * nb, 32))[0:nr], data1=vals.reshape((PT, G * nb, 32))[0:nr],
                       data2=sc.ap(pattern=[[G * nb, nr], [1, G * nb], [0, 32]], offset=0), op=nl.multiply)
    return e16

def engram_readout(pid, mine, T, Tp, hc, dim, hash_ids, etable, erow_start, e_wkv4, e_wkv_s, e_qk,
                   strm, stream0, rg_table):
    """The engram read-out of a block, both cores: gather this rank's shard rows of the
    n-gram table, sum the shards over `rg_table` (one rank holds each row, so the
    bf16 sum is exact), the fp8 `wkv` projection (this core's output columns), and
    the gate into `stream0[T, hc*dim]` from `strm`. Allocates its own scratch."""
    ncol = hash_ids.shape[1]
    ehd = engram_hd(etable)
    e_in = ncol * ehd
    e_out = e_wkv4.shape[1]
    emb = nl.ndarray((Tp, e_in), dtype=nl.bfloat16, buffer=nl.shared_hbm, name="emb")
    emb_sum = nl.ndarray((Tp, e_in), dtype=nl.bfloat16, buffer=nl.shared_hbm, name="emb_sum")
    ekv = nl.ndarray((Tp, e_out), dtype=nl.bfloat16, buffer=nl.shared_hbm, name="ekv")
    (engram_gather_fp8 if etable.dtype == nl.uint8 else engram_gather)(
        hash_ids, etable, erow_start, emb, mine, ncol, ehd, etable.shape[0])
    if pid == 0 and T < Tp:
        padz = nl.ndarray((PT, e_in), dtype=nl.bfloat16, buffer=nl.sbuf)
        nisa.memset(padz, 0.0)
        nisa.dma_copy(dst=emb[T:Tp, :], src=padz[0 : Tp - T, :])
    nisa.core_barrier(data=emb, cores=(0, 1))
    ncc.all_reduce(srcs=[emb], dsts=[emb_sum], replica_group=rg_table, op=nl.add)
    tiles = e_out // PT
    a = (tiles + 1) // 2
    lo, hi = (0, a * PT) if pid == 0 else (a * PT, e_out)
    X.gemm_rows(emb_sum, Tp, e_in, e_wkv4, e_wkv_s, ekv, lo, hi)
    nisa.core_barrier(data=ekv, cores=(0, 1))
    for r0, nr in mine:
        engram_gate_tile(r0, nr, strm, ekv, e_qk, stream0, hc, dim)
    nisa.core_barrier(data=stream0, cores=(0, 1))


def engram_gate_tile(r0, nr, h_hbm, kv_hbm, w_hbm, out_hbm, hc, dim, chunk=1024):
    """`kernels.engram_gate.gated_add` for one row tile: `h_hbm[T, hc*dim]` bf16 stream,
    `kv_hbm[T, (hc+1)*dim]` bf16 (key | value), `w_hbm[1, hc*dim]` fp32 -> `out_hbm`."""
    width = hc * dim
    nchunks = dim // chunk
    inv_dim = 1.0 / dim
    dim_rsqrt = float(dim) ** -0.5
    vf = []
    for j in range(nchunks):
        v = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
        nisa.dma_copy(dst=v[0:nr, :], src=kv_hbm[r0 : r0 + nr, width + j * chunk : width + (j + 1) * chunk])
        vf.append(v)
    for c in range(hc):
        base = c * dim
        hf = nl.ndarray((PT, dim), dtype=nl.float32, buffer=nl.sbuf)
        hsq = ksq = dotp = None
        for j in range(nchunks):
            lo = base + j * chunk
            hj = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=hj[0:nr, :], src=h_hbm[r0 : r0 + nr, lo : lo + chunk])
            nisa.tensor_copy(dst=hf[0:nr, j * chunk : (j + 1) * chunk], src=hj[0:nr, :])
            kj = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=kj[0:nr, :], src=kv_hbm[r0 : r0 + nr, lo : lo + chunk])
            wj = bcast_row(w_hbm[0:1, lo : lo + chunk], chunk, nr)
            prod = nl.multiply(nl.multiply(hj[0:nr, :], wj), kj[0:nr, :])
            sh = nl.sum(nl.square(hj[0:nr, :]), axis=1, keepdims=True)
            sk = nl.sum(nl.square(kj[0:nr, :]), axis=1, keepdims=True)
            sd = nl.sum(prod, axis=1, keepdims=True)
            hsq = sh if hsq is None else nl.add(hsq, sh)
            ksq = sk if ksq is None else nl.add(ksq, sk)
            dotp = sd if dotp is None else nl.add(dotp, sd)
        rstd = nl.multiply(
            rsqrt_newton(nl.add(nl.multiply(hsq, inv_dim), NORM_EPS)),
            rsqrt_newton(nl.add(nl.multiply(ksq, inv_dim), NORM_EPS)),
        )
        dot = nl.multiply(nl.multiply(dotp, rstd), dim_rsqrt)
        mag = nl.sqrt(nl.maximum(nl.abs(dot), 1e-6))
        sgn = nl.subtract(nl.multiply(nl.copy(nl.greater_equal(dot, 0.0), dtype=nl.float32), 2.0), 1.0)
        gate = nl.ndarray((PT, 1), dtype=nl.float32, buffer=nl.sbuf)
        gate[0:nr, :] = nl.sigmoid(nl.multiply(mag, sgn))
        for j in range(nchunks):
            yv = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.activation(dst=yv[0:nr, :], op=nl.copy, data=vf[j][0:nr, :], scale=gate[0:nr, 0:1])
            nisa.tensor_tensor(dst=yv[0:nr, :], data1=yv[0:nr, :], op=nl.add,
                               data2=hf[0:nr, j * chunk : (j + 1) * chunk])
            y16 = nl.ndarray((PT, chunk), dtype=nl.bfloat16, buffer=nl.sbuf)
            nisa.tensor_copy(dst=y16[0:nr, :], src=yv[0:nr, :])
            nisa.dma_copy(dst=out_hbm[r0 : r0 + nr, base + j * chunk : base + (j + 1) * chunk], src=y16[0:nr, :])


def tap_tile(r0, nr, stream_hbm, out_hbm, hc, dim, chunk=1024):
    """`out[rows] = mean over the hc copies of stream[rows]` in fp32 (the DSpark tap)."""
    for j in range(dim // chunk):
        acc = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
        for c in range(hc):
            t = nl.ndarray((PT, chunk), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=t[0:nr, :], src=stream_hbm[r0 : r0 + nr, c * dim + j * chunk : c * dim + (j + 1) * chunk])
            if c == 0:
                nisa.tensor_copy(dst=acc[0:nr, :], src=t[0:nr, :])
            else:
                nisa.tensor_tensor(dst=acc[0:nr, :], data1=acc[0:nr, :], data2=t[0:nr, :], op=nl.add)
        nisa.tensor_scalar(dst=acc[0:nr, :], data=acc[0:nr, :], op0=nl.multiply, operand0=1.0 / hc)
        nisa.dma_copy(dst=out_hbm[r0 : r0 + nr, j * chunk : (j + 1) * chunk], src=acc[0:nr, :])
