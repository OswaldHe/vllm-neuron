# SPDX-License-Identifier: Apache-2.0
"""The optimized `r1_idx` decode block megakernel of the flat scheme (`layer_decode_r1_idx_tp32`,
blocks 24, 28, 32, 36), with its own copies of the helper modules it calls: the optimized r1 decode kernel (`../r1_decode`)
with this archetype's sections of the generic body. `mk_kernels.layer` routes
(decode, (1, 0, 1, 0, 0), tp32) here.
"""

from . import blockquant, mk_common, mk_compress, mk_moe, mk_mx, r1_idx_decode  # noqa: F401
