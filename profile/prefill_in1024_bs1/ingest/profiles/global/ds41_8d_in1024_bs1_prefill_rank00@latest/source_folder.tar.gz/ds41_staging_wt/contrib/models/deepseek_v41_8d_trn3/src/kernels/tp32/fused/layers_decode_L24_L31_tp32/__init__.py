# SPDX-License-Identifier: Apache-2.0
"""The optimized fused decode launch `layers_decode_L24_L31_tp32` (see `layers_decode_L24_L31_tp32.py`) and its members' kernel packages."""
